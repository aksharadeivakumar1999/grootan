Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$FossFile,  
   [Parameter(Mandatory=$True,Position=2)]
   [string]$SummaryFile,
   [switch]$force = $false
)

$Path = $FossFile            #FossInfo XML file
$SummaryPath = $SummaryFile  #Summary XML file
[xml]$XmlDoc = Get-Content $Path
[xml]$SummaryXmlDoc = Get-Content $SummaryPath

Write-Host "Path:" $Path

Write-Host "Summary Path:" $SummaryPath

$Summarynodes = $SummaryXmlDoc.FossInfo.ChildNodes      #Nodes in Summary XML file
$Allnodes = $XmlDoc.FossInfo.ChildNodes                 #Nodes in FossInfo XML file

Write-Host "Number of ChildNodes in Summary Xml file" $Summarynodes.Count
Write-Host "Number of ChildNodes in FossInfo Xml file" $Allnodes.Count

foreach($node in $Allnodes)
{  
	$NodeName = $node.Name     #Node in FossInfo XML file
	Write-Host "`nNode Name" $NodeName
	
	$Summarynode = $SummaryXmlDoc.FossInfo.FossComponent |where {$_.name -eq $NodeName} #Node in Summary XML file
	Write-Host "SummaryNode Name" $Summarynode.Name
	
	$LicID = $node.License.LicenseID                  #License ID in FossInfo XML file
	$SummaryLicID = $Summarynode.License.LicenseID    #License ID in Summary XML file
	
	Write-Host "License ID" $LicID
	Write-Host "Summary License ID" $SummaryLicID
	
	#Comparing the License ID of both files
	if($LicID -ne $SummaryLicID)
	{
		$node.License.LicenseID = $SummaryLicID
		
		Write-Host "New License ID" $node.License.LicenseID	
	}
	else
	{
		Write-Host "License ID is same"
	}	
	
	#Sub Component nodes in FossInfo XML file
	$SubComponents = $node.SubComponent          
	$SubCompCount = $node.SubComponent.Count
	Write-Host "`t No. of SubComponents in FossInfo Xml file:"$SubCompCount
	
	#Sub Component nodes in Summary XML file
	$SummarySubComponents = $Summarynode.SubComponent
	$SummarySubCompCount = $Summarynode.SubComponent.Count
	Write-Host "`t No. of SubComponents in Summary Xml file:"$SummarySubCompCount
	
	#Comparing the License ID of Sub Component nodes of both files
	if($SubCompCount -ne 0)
	{
		foreach($subnode in $SubComponents)
		{
			$SubCompLicID = ""
			$SubCompSummaryLicID = ""
			
			foreach($summarysubnode in $SummarySubComponents)
			{
				if($subnode.License.Name -eq $summarysubnode.License.Name)
				{
					Write-Host "`t SubComponent License Name matched same"
					$SubCompLicID = $subnode.License.LicenseID
					$SubCompSummaryLicID = $summarysubnode.License.LicenseID
					
					Write-Host "`t SubComponent License ID" $SubCompLicID
					Write-Host "`t SubComponent Summary License ID" $SubCompSummaryLicID
					
					if($SubCompLicID -ne $SubCompSummaryLicID)
					{
						$subnode.License.LicenseID = $SubCompSummaryLicID
						
						Write-Host "`t SubComponent New License ID" $subnode.License.LicenseID	
					}
					else
					{
						Write-Host "`t SubComponent License ID is same"
					}					
					break
				}
			}
				
		}			
	}
}

$XmlDoc.Save($Path)


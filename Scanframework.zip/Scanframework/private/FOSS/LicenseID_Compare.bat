@echo off
REM *********************************************************************************************************************************
REM Copy all FOSSInfo.xml files in ThirdPartyLicenses folder to UpdatedXML folder
REM LicenseID_Compare.ps1 will compare the FOSSInfo.xml in ThirdPartyLicenses\UpdatedXML folder with Summary.xml in ThirdPartyLicenses\Summary folder
REM UpdatedXML folder is a gitignore folder 
REM ********************************************************************************************************************************

REM Deleting the old files in UpdatedXML folder
del %CD%\ThirdPartyLicenses\UpdatedXML\*.xml /Y

REM Copying the XML files to UpdatedXML folder
copy %CD%\ThirdPartyLicenses\*.xml %CD%\ThirdPartyLicenses\UpdatedXML /Y

REM Calling the powershell script for each project for License ID Updation
powershell %CD%\LicenseID_Compare.ps1 %CD%\ThirdPartyLicenses\UpdatedXML\BR_BSPAPI.FOSSInfo.xml %CD%\ThirdPartyLicenses\Summary\Summary_BR_BSPAPI.xml

powershell %CD%\LicenseID_Compare.ps1 %CD%\ThirdPartyLicenses\UpdatedXML\BR_EXTMOD.FOSSInfo.xml %CD%\ThirdPartyLicenses\Summary\Summary_BR_EXTMOD.xml

powershell %CD%\LicenseID_Compare.ps1 %CD%\ThirdPartyLicenses\UpdatedXML\CML65_BSP.FOSSInfo.xml %CD%\ThirdPartyLicenses\Summary\Summary_CML65_BSP.xml

powershell %CD%\LicenseID_Compare.ps1 %CD%\ThirdPartyLicenses\UpdatedXML\FUNCMOD.FOSSInfo.xml %CD%\ThirdPartyLicenses\Summary\Summary_FUNCMOD.xml

powershell %CD%\LicenseID_Compare.ps1 %CD%\ThirdPartyLicenses\UpdatedXML\VxWorks.FOSSInfo.xml %CD%\ThirdPartyLicenses\Summary\Summary_VxWorks.xml


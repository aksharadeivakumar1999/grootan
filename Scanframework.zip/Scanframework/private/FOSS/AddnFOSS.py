import ssl
import lxml.html as lh
import pandas as pd
from bs4 import BeautifulSoup
import requests
from requests_kerberos import HTTPKerberosAuth, OPTIONAL
import sys

# Authenticate
context = ssl.create_default_context()
der_certs = context.get_ca_certs(binary_form=True)
pem_certs = [ssl.DER_cert_to_PEM_cert(der) for der in der_certs]
with open('wincacerts.pem', 'w') as outfile:
   for pem in pem_certs:
      outfile.write(pem + '\n')

kerberos_auth = HTTPKerberosAuth(mutual_authentication=OPTIONAL)
url = 'https://inside-docupedia.bosch.com/confluence/display/FOSSDC/Additional+OSS+Licenses+for+DC'
r = requests.get(url, auth=kerberos_auth, verify = 'wincacerts.pem')

#Parsing
if (r.ok == 1):
   print 'Access Permitted for Docupedia'

   doc = lh.fromstring(r.content)
   tr_elements = doc.xpath('//div[@id="page"]//div[@class="page view"]//div[@class="table-wrap"]//table//tbody//tr')
   col=[]
   i=0
   for t in tr_elements[0]:
       i+=1
       name=t.text_content()
       col.append((name,[]))

   for j in range(1,len(tr_elements)):    
       T=tr_elements[j]    #T is our j'th row              
         
       i=0 #i is the index of our column
       
       #Iterate through each element of the row
       for t in T.iterchildren():
           data=t.text_content() 
           #Check if row is empty
           if i>0:
           #Convert any numerical value to integers for storing the array
               try:
                   data=int(data)
               except:
                   pass
           col[i][1].append(data)
           
           i+=1 #Increment i for the next column


   LicenseArr = col[3][1] #Assign the License Name column to an array 
   
   Lic_reqd = sys.argv[1]
   x=0
   LicenseIdVal = ''
   #Iterate through each element of the License Name column 
   for x in range(0,len(LicenseArr)):
       if (LicenseArr[x] == Lic_reqd):
           LicenseIdVal = col[0][1][x]
           break

   #Check if License was found
   if (LicenseIdVal == ''):
      print 'License Name not Found'
      print ''
   else:
      print 'License Name Found'
      print LicenseIdVal

else:
   print 'Access for Docupedia Denied!!'

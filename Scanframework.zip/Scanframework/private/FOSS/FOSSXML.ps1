Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$Project,  
   [Parameter(Mandatory=$True,Position=2)]
   [string]$LicenseFile,
   [Parameter(Mandatory=$True,Position=3)]
   [string]$SearchPath,  
   [switch]$force = $false
)

Write-Host "Generating FOSS Info for $Project from $LicenseFile ExcelSheet "
Write-Host "License Files are in  $SearchPath"
$XMLFileName = -join($Project, ".FOSSInfo")   #Ex: VXWorks.FOSSInfo

$XMLFilePath = "$pwd\$XMLFileName.xml"
$ExcelFilePath = "$SearchPath\$LicenseFile.xlsx"
$WhitelistExcelFilePath = "$pwd\DCCD-08885-000_ANH_N_EN_2018-03-19.xlsx"

#Creating Main node for the XML file
$xmlsettings = New-Object System.Xml.XmlWriterSettings
$xmlsettings.CheckCharacters = $false
$xmlsettings.Indent = $true
$xmlsettings.IndentChars = ("\t")
$XmlWriter = [System.XML.XmlWriter]::Create($XMLFilePath, $xmlsettings)
$XmlWriter.WriteStartDocument()

$XmlWriter.WriteStartElement("FossInfo")
$XmlWriter.WriteAttributeString("Name", $Project)
$XmlWriter.WriteEndElement() 
$XmlWriter.WriteEndDocument()
$XmlWriter.Flush()
$XmlWriter.Close()

#Open XML file
$XmlDoc = [System.Xml.XmlDocument](Get-Content $XMLFilePath)
$MainNode = $XmlDoc.FossInfo

#Adding Schemas description to FossInfo Node
$MainNode.SetAttribute("xmlns","http://rexroth/2/foss-components")
$MainNode.SetAttribute("xmlns:xsi","http://www.w3.org/2001/XMLSchema-instance")
$attr = $XmlDoc.CreateAttribute('xsi', 'schemaLocation', 'http://www.w3.org/2001/XMLSchema-instance')
$attr.Value = "http://rexroth/2/foss-components ../.BuildTools/LicenseInfoFOSSv2.xsd"
$MainNode.Attributes.Append($attr)

#Open Excel file
$Excel = New-Object -Com Excel.Application
$Workbook = $Excel.Workbooks.Open($ExcelFilePath) 
$WorkSheet = $Workbook.Sheets.Item(1)
Write-Host "WorkSheet Name:" $WorkSheet.Name
$RowCount = $WorkSheet.UsedRange.Rows.Count
$ColumnCount = $WorkSheet.UsedRange.Columns.Count

Write-Host "Row Count" $RowCount

if ($RowCount -le 2)
{
	$FirstVal = $WorkSheet.Cells.Item(2,1).Value2
	if ($FirstVal -eq $null)
	{
		Write-Host "No Component Information Available!!"
		$Excel.Quit()
		$XmlDoc.Save($XMLFilePath)
		exit 0
	}
	else
	{
		$i = 2  #Only One Component Information is available
	}
}
else
{
	$FirstVal = $WorkSheet.Cells.Item(2,1).Value2
	if ($FirstVal -eq $null)
	{
		$i = 3  #First 2 Rows Merged for Header
	}
	else
	{
		$i = 2  #Rows are not Merged for Header
	}
}

#Extracting the Column Number 
for ([char]$chr = 'A'; $chr -le 'G'; $chr = [byte]$chr + 1)
{
	$rng = -join($chr, "1")
	$col = $WorkSheet.Range($rng).MergeArea.Column
	$header = $WorkSheet.Cells.Item(1,$col).Value2
	
	if($header -ne $null)
	{
		$header = $header.Trim()
	}
	
	switch ($header){
		"Component"             { $CompCol = $col ; break }
		"Version"               { $VerCol = $col ; break }
		"License"               { $LicCol = $col ; break }
		"Homepage / Source"     { $HomeCol = $col ; break }      # Vxworks & PR41-BSP have Homepage / Source
		"Homepage"              { $HomeCol = $col ; break }
		"Copyright"             { $CprightCol = $col ; break }
		"Obligations"           { $ObnCol = $col ; break }
		"Integration Mechanism" { $IntCol = $col ; break }
		"Usage"                 { $UsageCol = $col ; break }
	}
}

#Open Whitelist Excel file
$WhitelistExcel = New-Object -Com Excel.Application
$WhitelistWorkbook = $WhitelistExcel.Workbooks.Open($WhitelistExcelFilePath) 
$WhitelistWorkSheet = $WhitelistWorkbook.Sheets.Item(2)
Write-Host "Whitelist WorkSheet Name:" $WhitelistWorkSheet.Name

#Extract Data from excel and input to xml
for (; $i -le $RowCount; $i++)
{
	$Notice = ""
	$LicenseName = ""
	$LicenseID	= ""
	$ShortName	= ""
	$SPDX	= ""
	$LicenseTxt = ""
	$FullfilledObn = ""
	$UnfullfilledObn = ""
	$IDValue = ""
    $LicenseNotice = $null
	Write-Host "`nRow Number:" $i
	
	#Extracting Data from the FOSS_LICENSE.xlsx
	$Component = $WorkSheet.Cells.Item($i,$CompCol).Value2.Trim()
	$Version = $WorkSheet.Cells.Item($i,$VerCol).Value2
	$License = $WorkSheet.Cells.Item($i,$LicCol).Value2	
	$Copyright = $WorkSheet.Cells.Item($i,$CprightCol).Value2
	$Source = $WorkSheet.Cells.Item($i,$HomeCol).Value2
	
	
	if($ObnCol -ne $null)
	{
		#Extracting Fulfilled and Unconfirmed Obligations from the LICENSE.xlsx
		$Fulcol = $ObnCol
		$UnFulcol = $ObnCol + 1
		$FullfilledObn = $WorkSheet.Cells.Item($i,$Fulcol).Value2
		$UnfullfilledObn = $WorkSheet.Cells.Item($i,$UnFulcol).Value2
		
		if($FullfilledObn -ne $null)
		{
			$SplitObn = $FullfilledObn.Split([Environment]::NewLine)
			$Count = $SplitObn.GetUpperBound(0)
			$Typelist1 = new-object system.collections.arraylist
			$Desclist1 = new-object system.collections.arraylist			
			for($g=0; $g -le $Count; $g++)
			{
				$Str = $SplitObn[$g]| Measure-Object -Character
				$len = $Str.Characters
				if($len -gt 40)
				{
					$Desclist1.Add($g)>$null
				}
				else
				{
					$Typelist1.Add($g)>$null
				}	
			}		
		}
		
		if($FullfilledObn -eq "complete")
		{
			Write-Host "Obligations Details Not available" 
			$FullfilledObn = $null
		}
		
		if($FullfilledObn -eq "completed")
		{
			Write-Host "Obligations Details Not available" 
			$FullfilledObn = $null
		}
		
		if($UnfullfilledObn -ne $null)
		{
			$SplitUnObn = $UnfullfilledObn.Split([Environment]::NewLine)
			$UnCount = $SplitUnObn.GetUpperBound(0)
			$Typelist = new-object system.collections.arraylist
			$Desclist = new-object system.collections.arraylist			
			for($j=0; $j -le $UnCount; $j++)
			{
				$Str = $SplitUnObn[$j]| Measure-Object -Character
				$len = $Str.Characters
				if($len -gt 25)
				{
					$Desclist.Add($j)>$null
				}
				else
				{
					$Typelist.Add($j)>$null
				}	
			}		
		}
	}
	else
	{
		Write-Host "Obligations Details Not available" 
		$FullfilledObn = $null
		$UnfullfilledObn = $null
	}	
	
	#Usage default value used as AsIs if details are not mentioned
	if($UsageCol -ne $null)
	{
		$Usage = $WorkSheet.Cells.Item($i,$UsageCol).Value2
	}
	else
	{
		$Usage = "AsIs"
	}
	
	#Integration Mechanism default value used as Snippet if details are not mentioned
	if($IntCol -ne $null)
	{

		$IntMech = $WorkSheet.Cells.Item($i,$IntCol).Value2
		if($IntMech -eq $null)
		{
			$IntMech = "Snippet"
		}	
	}
	else
	{
		$IntMech = "Snippet"
	}	
	
	#Extracting License Information from text files	
	$filename = -join($Component,"_LICENSE", "*.txt")
	Get-ChildItem -Path $SearchPath -Filter $filename -Recurse | %{
	$Text = Get-Content -Path $_.FullName -Raw
	$LicenseTxt = -join($Text)
	}
	
	#Finding License ID
	if($License -ne $null)
	{
		#Finding License ID from the Open Source Whitelist Excel file
		$LicenseName = $License.Trim()
		$Found = $WhitelistWorkSheet.UsedRange.Find($LicenseName)
		if ($Found.Text -eq $LicenseName)
		{
		  Write-Host "Found match in DC Open Source Whitelist"
		  $LicenseID = $WhitelistWorkSheet.Cells.Item($Found.Row,1).Value2
		  $ShortName = $WhitelistWorkSheet.Cells.Item($Found.Row,2).Value2
		  $SPDX = $WhitelistWorkSheet.Cells.Item($Found.Row,3).Value2
		  Write-Host "License ID :" $LicenseID
		}
		else
		{
			if($Found -ne $null)
			{
				$BeginAddress = $Found.Address(0,0,1,1)

				Do {
					$Found = $WhitelistWorkSheet.Cells.FindNext($Found)
					$Address = $Found.Address(0,0,1,1)
					If ($Address -eq $BeginAddress) {
						BREAK
					}
					if ($Found.Text -eq $LicenseName)
						{
						  Write-Host "Found exact match" $Found.Text
						  $LicenseID = $WhitelistWorkSheet.Cells.Item($Found.Row,1).Value2
						  $ShortName = $WhitelistWorkSheet.Cells.Item($Found.Row,2).Value2
						  $SPDX = $WhitelistWorkSheet.Cells.Item($Found.Row,3).Value2
						  Write-Host "License ID :" $LicenseID
						  BREAK
						}                 
				} Until ($False)
			}
		}		
		
		if($LicenseID -eq "")
		{
			#Finding License ID from Docupedia Page
			$IDValue =  $(python $pwd\AddnFOSS.py $LicenseName)
			
			if($IDValue.count -gt 1)
			{
				Write-Host $IDValue[0]
				if($IDValue[2] -eq "")
				{
					$LicenseID = $null
				}
				else
				{
					$LicenseID = $IDValue[2]
				}
			}
			else
			{
				Write-Host $IDValue				
				$LicenseID= $null
			}
			
			if($LicenseID -eq $null)
			{
				Write-Host "License ID Not Found"
			}
			else
			{			
				Write-Host "Found match in Additional FOSS Licenses for DC"
				Write-Host "License ID :" $LicenseID
			}			
		}
	}
	else
	{
		Write-Host "License Information Not specified!!"
	}
	
	#Adding data to XML file
	if($Component -match "_Sub")
	{
		#Adding data to SubComponent Node 
		Write-Host "Found Subcomponent"
		$MainComponentName = ""
		$NameComp = ""
		
		for($o=$i-1; $o -ge 0; $o--)
		{
			$NameComp = $WorkSheet.Cells.Item($o,$CompCol).Value2.Trim()
			if($NameComp -match "_Sub")
			{
				continue
			}
			else
			{
				$MainComponentName = $NameComp
				Write-Host "Main ComponentName for the Subcomponent : " $MainComponentName
				break
			}
		}
		
		
		$SubCompMainNode = $MainNode.FossComponent |where {$_.name -eq $MainComponentName}		
		$NodeComment = $SubCompMainNode.AppendChild($XmlDoc.CreateComment("$Component"))
		$NodeSubComponent = $SubCompMainNode.AppendChild($XmlDoc.CreateElement("SubComponent"))
		
		$NodeCprightSub = $NodeSubComponent.AppendChild($XmlDoc.CreateElement("Copyright"))
		$NodeCprightSub.SetAttribute("Text",$Copyright)
		
		$NodeLicenseSub = $NodeSubComponent.AppendChild($XmlDoc.CreateElement("License"))
		$NodeLicenseSub.SetAttribute("Name",$LicenseName)
		$NodeLicenseSub.SetAttribute("Shortname",$ShortName)
		$NodeLicenseSub.SetAttribute("Version","")
		$NodeLicenseSub.SetAttribute("Spdx",$SPDX)
		$NodeLicenseSub.SetAttribute("LicenseID",$LicenseID)

		$NodeTextSub = $NodeLicenseSub.AppendChild($XmlDoc.CreateElement("Text"))
		$NodeTextSub.SetAttribute("Format", "txt")
        $NodeTextSubCDATA = $NodeTextSub.AppendChild($XmlDoc.CreateCDataSection("$LicenseTxt"))
                		
		#Checking if obligations are added in the main component
		if($FullfilledObn -ne $null)
		{
			for($p=0; $p -lt $Typelist1.count; $p++)
			{
				$SubObn = $SplitObn[$Typelist1[$p]]
				$Obnfound = 0
				$MainObnnodes = $SubCompMainNode.Fulfilled.Obligation				
				$ObnCount = $MainObnnodes.Count
				
				if($ObnCount -ne 0)
				{
					foreach($node in $MainObnnodes)
					{				
						$MainObn = $node.Type						
						if($SubObn -eq $MainObn)
						{
							$Obnfound = $Obnfound + 1
							break
						}
					}
					
					if($Obnfound -eq 0)
					{
						Write-Host "Need to add the obligation!!" $SubObn
						$NodeFulfilledSub = $SubCompMainNode.Fulfilled
						$NodeFulfilledObnSub = $NodeFulfilledSub.AppendChild($XmlDoc.CreateElement("Obligation"))
						$NodeFulfilledObnSub.SetAttribute("Type",$SubObn)
					}
				}
				else
				{
					Write-Host "No Obligations Found. Adding now!"
					$NodeFulfilledObnSub = $SubCompMainNode["Fulfilled"].AppendChild($XmlDoc.CreateElement("Obligation"))
					$NodeFulfilledObnSub.SetAttribute("Type",$SubObn)
				}				
				
			}
			
		}
		
		if($UnfullfilledObn -ne $null)
		{
			for($q=0; $q -lt $Typelist.count; $q++)
			{
				$SubUnConfObn = $SplitUnObn[$Typelist[$q]]
				$UnConfObnfound = 0
				$MainUnConfObnnodes = $SubCompMainNode.Unconfirmed.Obligation					
				$UnConfObnCount = $MainUnConfObnnodes.Count
				
				if($UnConfObnCount -ne 0)
				{
					foreach($node in $MainUnConfObnnodes)
					{
						$MainUnConfObn = $node.Type
						
						if($SubUnConfObn -eq $MainUnConfObn)
						{
							$UnConfObnfound = $UnConfObnfound + 1
							break
						}
					}
					
					if($UnConfObnfound -eq 0)
					{
						Write-Host "Need to add the Unconfirmed obligation!!"
						$NodeUnConfSub = $SubCompMainNode.Unconfirmed
						$NodeUnConfObnSub = $NodeUnConfSub.AppendChild($XmlDoc.CreateElement("Obligation"))
						$NodeUnConfObnSub.SetAttribute("Type",$SubUnConfObn)
					}
				}
				else
				{
					Write-Host "No Unconfirmed Obligations Found. Adding now!"
					$NodeUnConfObnSub = $SubCompMainNode["Unconfirmed"].AppendChild($XmlDoc.CreateElement("Obligation"))
					$NodeUnConfObnSub.SetAttribute("Type",$SubUnConfObn)
				}
				
			}
		}
		
	}
	else
	{
		#Adding data to Main Component Node 
		$NodeComponent = $MainNode.AppendChild($XmlDoc.CreateElement("FossComponent"))
		$NodeComponent.SetAttribute("Name",$Component)
		$NodeComponent.SetAttribute("HomePage",$Source)
		$NodeComponent.SetAttribute("Usage",$Usage)
		$NodeComponent.SetAttribute("IntegrationMechanism",$IntMech)
		$NodeComponent.SetAttribute("Version",$Version)

		#Adding Copyright Node 
		$NodeCopyright = $NodeComponent.AppendChild($XmlDoc.CreateElement("Copyright"))
		$NodeCopyright.SetAttribute("Text",$Copyright)

		$SubnodeNotice = $NodeCopyright.AppendChild($XmlDoc.CreateElement("Notice"))
        $SubnodeNotice.SetAttribute("Format", "txt")
		$SubnodeNotice.InnerText = $Notice

		#Adding Fulfilled Obligations Node
		$NodeFulfilled = $NodeComponent.AppendChild($XmlDoc.CreateElement("Fulfilled"))
		$NodeFulfilled.InnerText = ""
		if($FullfilledObn -ne $null)
		{
			for($k=0; $k -lt $Typelist1.count; $k++)
			{
				$TypeName = $SplitObn[$Typelist1[$k]]
				$Desc = ""
				$Description = ""
				$start = $Typelist1[$k] + 1
				for($h=$start; $h -le $Desclist1[$Desclist1.count - 1]; $h++)
				{
					if($h -eq $Typelist1[$k + 1])
					{
						break
					}
					$Desc = -join($Desc,"`n`t", $SplitObn[$h])				
				}
				
				$Description = -join($Desc.Trim(),"`n`t`t")
				$SubnodeFulfilled = $NodeFulfilled.AppendChild($XmlDoc.CreateElement("Obligation"))		
			   
				$SubnodeFulfilled.SetAttribute("Type",$TypeName)
				
				#Add Description only if string is not null or whitespace
				if(![string]::IsNullOrWhitespace($Description))
				{                
					if($TypeName -eq "NoticeinDocumentation")
					{
						$LicenseNotice = $Description
					}
					else
					{
						$SubNodeDescription = $SubnodeFulfilled.AppendChild($XmlDoc.CreateElement("Description"))
						$SubNodeDescription.InnerText = $Description
					}
				}
			}
		}
		
		#Adding Unconfirmed Obligations Node
		$NodeUnconfirmed = $NodeComponent.AppendChild($XmlDoc.CreateElement("Unconfirmed"))
		$NodeUnconfirmed.InnerText = ""
		if($UnfullfilledObn -ne $null)
		{
			for($l=0; $l -lt $Typelist.count; $l++)
			{
				$TypeName = $SplitUnObn[$Typelist[$l]]
				$Desc = ""
				$Description = ""
				$start = $Typelist[$l] + 1
				for($m=$start; $m -le $Desclist[$Desclist.count - 1]; $m++)
				{
					if($m -eq $Typelist[$l + 1])
					{
						break
					}
					$Desc = -join($Desc,"`n`t", $SplitUnObn[$m])				
				}
				
				$Description = -join($Desc.Trim(),"`n`t`t")
				$SubnodeUnFulfilled = $NodeUnconfirmed.AppendChild($XmlDoc.CreateElement("Obligation"))		
			   
				$SubnodeUnFulfilled.SetAttribute("Type",$TypeName)
				
				#Add Description only if string is not null or whitespace
				if(![string]::IsNullOrWhitespace($Description))
				{                
					if($TypeName -eq "NoticeinDocumentation")
					{
						$LicenseNotice = $Description
					}
					else
					{
						$SubNodeDescription = $SubnodeUnFulfilled.AppendChild($XmlDoc.CreateElement("Description"))
						$SubNodeDescription.InnerText = $Description
					}
				}
			}
		}

		#Adding License Node
		$NodeLicense = $NodeComponent.AppendChild($XmlDoc.CreateElement("License"))
		$NodeLicense.SetAttribute("Name",$LicenseName)
		$NodeLicense.SetAttribute("Shortname",$ShortName)
		$NodeLicense.SetAttribute("Version","")
		$NodeLicense.SetAttribute("Spdx",$SPDX)
		$NodeLicense.SetAttribute("LicenseID",$LicenseID)
		
		$SubnodeText = $NodeLicense.AppendChild($XmlDoc.CreateElement("Text"))
        $SubnodeText.SetAttribute("Format", "txt")
        $SubnodeCDATA = $SubnodeText.AppendChild($XmlDoc.CreateCDataSection("$LicenseTxt"))
                		
		if ($LicenseNotice -ne $null)
		{
			$LicSplit =""
			$LicCount = $LicenseNotice.Split([Environment]::NewLine).GetUpperBound(0)
			$LicSplit = $LicenseNotice.Split([Environment]::NewLine)
		
			for($n=0; $n -lt $LicCount; $n++)			
			{
				$SubNodeLicNotice = $NodeLicense.AppendChild($XmlDoc.CreateElement("Notice"))			
				$SubNodeLicNotice.InnerText = $LicSplit[$n].Trim()
			}
		}
	}	
	
	#Resetting the Arrays
	$Typelist = @()
	$Typelist1 = @()
	$Desclist = @()
	$Desclist1 = @()
}

$XmlDoc.Save($XMLFilePath)
$Excel.Quit()
$WhitelistExcel.Quit()

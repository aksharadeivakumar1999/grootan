@echo off

REM Calling PowerShell Script to encrpyt the Username and Password
powershell .\encrypt.ps1
pause

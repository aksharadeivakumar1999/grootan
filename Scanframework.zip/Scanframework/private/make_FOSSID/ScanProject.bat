@echo off
REM --------------------------------------
REM %1 - Scan Code
REM %2 - Specific Scan Code
REM %3 - BASISFW version
REM --------------------------------------

REM Calling ScanInformation, RunScan, ScanFinding, GenerateReport Scripts sequentially for each Scan Project
set ERR=0

REM ---Calling powershell script to print scan information---
powershell %cd%\ScanInformation.ps1 %1
if %ERRORLEVEL% NEQ 0 (
	echo Scan Information Failed!!
	set ERR=1
)

REM ---Calling powershell script to run scan---
powershell %cd%\RunScan.ps1 %1 %2
if %ERRORLEVEL% NEQ 0 (
	echo Run Scan Failed!!
	set ERR=2 
	goto error
)

REM ---Calling powershell script to print the scan findings---
powershell %cd%\ScanFindings.ps1 %1 %3
if %ERRORLEVEL% NEQ 0 (
	echo Scan Findings Failed!!
	set ERR=3 
)

REM ---Calling powershell script to generate report for the scan---
powershell %cd%\GenerateReport.ps1 %1
if %ERRORLEVEL% NEQ 0 (
	echo Generate Report Failed!!
	set ERR=4 
)

REM ---Error Evaluation---
if %ERR% NEQ 0 (
	goto error
)

:success
	:: Success
	COLOR A0
	exit /B 0

:error
	:: Error
	COLOR C0
	exit /B 1

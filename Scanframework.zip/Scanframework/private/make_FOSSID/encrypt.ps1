# UserName - bat9er
$username = read-host -prompt "Enter your Username [username]: "
$password = read-host -prompt "Enter your Password: "
write-host "Password and Username will be saved encrypted"

$secure = ConvertTo-SecureString $username -force -asPlainText
$bytesUN = ConvertFrom-SecureString $secure

$secure = ConvertTo-SecureString $password -force -asPlainText
$bytesPwd = ConvertFrom-SecureString $secure

$bytesPwd | out-file .\password.sec
$bytesUN | out-file .\username.sec

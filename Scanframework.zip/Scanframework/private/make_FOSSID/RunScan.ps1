# Mandatory parameters to run this script are:
# $ScanCode - This is the Scan Code of BSP project
# $IdentificationScanCode - This scan code is used to reuse identifications for BSP projects
# $force - Disabling force to avoid prompting during run time
Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$ScanCode,
   [Parameter(Mandatory=$True,Position=2)]
   [string]$IdentificationScanCode,
   [switch]$force = $false
)

# Headers required to run the WebApp API
$headers = @{}
$headers.Add("ContentType", "application/zip")

# URL to login to FOSSID DC Instance
$urlp= "https://rb-fossid.de.bosch.com/DC/api.php"

# Decrypt Password and Username
$bytesUser = Get-Content $pwd\username.sec
$bytesKey = Get-Content $pwd\password.sec
$username = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $bytesUser)))
$key = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $bytesKey)))

# Downloading latest Content from Git
Write-Host "`nDownloading content from Git..."
$download_body = @{
					 group = "scans"
					 action = "download_content_from_git"
					 data = @{username = $username;
							  key = $key;
							  scan_code = $ScanCode
							}
				}| convertto-json

# Getting the response of the content downloaded from Git
$response = Invoke-WebRequest -Method post -Uri $urlp -Body $download_body -Headers $headers
$responseobj = $response.Content | ConvertFrom-Json

Write-Host "Download WebApp API returns status Code :" $response.StatusCode
if(($response.StatusCode -eq 200) -and ($responseobj.status -eq 1))
{
	Write-Host "Download Content WebApp API call worked fine"
}
else
{	
	Write-Host "Download Content WebApp API call Failed!!"
	Write-Host "Error Message:"	$responseobj.error
	exit 1
}

Start-Sleep -Seconds 300

# Checking the download status
Write-Host "`nChecking the download status..."
$rerun = 1
while($rerun)
{
	 $download_status_body = @{
								 group = "scans"
								 action = "check_status_download_content_from_git"
								 data = @{username = $username;
										  key = $key;
										  scan_code = $ScanCode
										 }
							}| convertto-json
				 
	# Getting the response of the Download Status WebApp API
	$response = Invoke-WebRequest -Method post -Uri $urlp -Body $download_status_body -Headers $headers
	$responseobj = $response.Content | ConvertFrom-Json

	Write-Host "Download Status WebApp API returns status Code :" $response.StatusCode
	if(($response.StatusCode -eq 200) -and ($responseobj.status -eq 1))
	{
		Write-Host "Download Status WebApp API call worked fine"
	}
	else
	{	
		Write-Host "Download Status WebApp API call Failed!!"
		Write-Host "Error Message:"	$responseobj.error
		exit 1
	}
	
	# Checking if contents have been successfully downloaded from git [Both Develop & Hotfix versions of BASISFW]
	if($responseobj.data -ne "FINISHED")
	{
		Start-Sleep -Seconds 60  # Giving an additional delay before checking again
		$rerun = 1
	}
	else
	{
		$rerun = 0
	}
}

# Calling the Run Scan API
Write-Host "`nRunning the scan....."
$ReuseIdentification = 1
# This special check is for HCQ02 BSP project because we don't have a reference scan project from protex for reusing identifications while scanning
$HCQ02_Reuse = 0   # Flag to set for HCQ02 scan code
if ($ScanCode -eq "DC__EHE6_HCQ02-BSP_dev_378" -or $ScanCode -eq "DC__EHE6_HCQ02-BSP_hotfix14V22_391") # Scan codes of HCQ02-BSP Project for Develop & Hotfix14V22 version respectively
{
	$ReuseIdentification = 0
	$HCQ02_Reuse = 1
}

$runscan_body = @{
					group = "scans"
					action = "run"
					data = @{username = $username;
							 key = $key;
							 scan_code = $ScanCode;
							 limit = "10";
							 sensitivity = "10";
							 replace_existing_identifications = "0";
							 reuse_identification = "$ReuseIdentification";
							 identification_reuse_type = "specific_scan";
							 specific_code = $IdentificationScanCode;
							 auto_identification_detect_declaration = "1";
							 auto_identification_detect_copyright = "1";
							 auto_identification_resolve_pending_ids = "0";
							 scan_failed_only = "0";
							 delta_only = "0";
							 full_file_only = "0"
						}
				}| convertto-json

# Editing the 'run' API json to remove 'identification_reuse_type' & 'specific_code' field while scanning for HCQ02 BSP Project
if ($HCQ02_Reuse -eq 1)
{
	$runscan_body = $runscan_body | convertfrom-json
	$runscan_body[0].data.PSObject.Properties.Remove('identification_reuse_type')
	$runscan_body[0].data.PSObject.Properties.Remove('specific_code')
	$runscan_body = $runscan_body | convertto-json
}

# Getting the response of the Run Scan WebApp API
$response = Invoke-WebRequest -Method post -Uri $urlp -Body $runscan_body -Headers $headers
$responseobj = $response.Content | ConvertFrom-Json

Write-Host "Run Scan WebApp API returns status Code :" $response.StatusCode
if(($response.StatusCode -eq 200) -and ($responseobj.status -eq 1))
{
	Write-Host "Run Scan WebApp API call worked fine"
}
else
{
	Write-Host "Run Scan WebApp API call Failed!!"
	Write-Host "Error Message:"	$responseobj.error
	exit 1
}

Start-Sleep -Seconds 300

# Checking the Scan status
Write-Host "`nChecking the scan status..."
$rerun = 1
while($rerun)
{
	$scan_status_body = @{
							 group = "scans"
							 action = "check_status"
							 data = @{username = $username;
									  key = $key;
									  scan_code = $ScanCode;
									  type = "SCAN"; 
									  delay_response = "5"
									 }
						}| convertto-json

	# Getting the response of the Check Status WebApp API
	$response = Invoke-WebRequest -Method post -Uri $urlp -Body $scan_status_body -Headers $headers
	$responseobj = $response.Content | ConvertFrom-Json
	
	if(($response.StatusCode -eq 200) -and ($responseobj.status -eq 1))
	{
		Write-Host "Scan Check Status WebApp API call worked fine"
	}
	else
	{	
		Write-Host "Scan Check Status WebApp API call Failed!!"
		Write-Host "Error Message:"	$responseobj.error
		exit 1
	}

	if($responseobj.data.is_finished -ne 1)
	{
		Start-Sleep -Seconds 60   # Giving an additional delay before checking again
		$rerun = 1
	}
	else
	{
		$rerun = 0
		Write-Host "Scan Check Status WebApp API returns status Code :" $response.StatusCode
		Write-Host "Scan status:" $responseobj.data.status
	}

}

# Refreshing the physical files in the scan project to keep only the required contents in the filesystem
Write-Host "`nRefreshing the Scan Projects..."
$refresh_files = @{
					 group = "scans"
					 action = "refresh_files"
					 data = @{username = $username;
							  key = $key;
							  scan_code = $ScanCode;
							 }
				}| convertto-json

# Getting the response of the Refresh Files WebApp API
$response = Invoke-WebRequest -Method post -Uri $urlp -Body $refresh_files -Headers $headers
$responseobj = $response.Content | ConvertFrom-Json

Write-Host "Refresh Files WebApp API returns status Code :" $response.StatusCode
if(($response.StatusCode -eq 200) -and ($responseobj.status -eq 1))
{
	Write-Host "Refresh Files WebApp API call worked fine"
	Write-Host "Changes in the filesystem (file(s) added/deleted):" $responseobj.data.message
}
else
{	
	Write-Host "Refresh Files WebApp API call Failed!!"
	Write-Host "Error Message:"	$responseobj.error
	exit 1
}
exit 0

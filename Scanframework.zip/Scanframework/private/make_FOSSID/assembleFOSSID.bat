@echo off

REM ---Upload assembled zip file to local folder & add date and time to zip file---
set ASSEMBLE_ERR=0

REM ---Get date---
for /F "tokens=1-3 delims=/." %%A in ("%Date%") do (
    set Day=%%A
    set Month=%%B
    set Year=%%C
)

REM ---Get time---
for /F "tokens=1-3 delims=/:, " %%A in ("%Time%") do (
    set Hours=%%A
    set Minutes=%%B
    set Seconds=%%C
)

REM ---Adding a leading zero---
if "%Hours%" LSS 10 (
    set Hours = 0%Hours%
)

REM ---Zipping all FOSSID Reports---
7z a .\..\..\..\..\..\..\Test_System\FOSSID\assembles\assemble.zip .\..\log\*
if %ERRORLEVEL% NEQ 0 ( set ASSEMBLE_ERR=1 )

REM ---Checking if the build number is valid then appending it along with FWVER to the assemble.zip filename---
echo %BUILD_NUMBER%|findstr /xr "[1-9][0-9]*">nul
if %ERRORLEVEL% NEQ 0 (
	set ASSEMBLE_ERR=1
	echo ERROR, Build Number: %BUILD_NUMBER% is Invalid!! Renaming the zip file without the Build number!!
	set new_file_name=assembleFOSSID_%FWVER%_%Year%-%Month%-%Day%_%Hours%-%Minutes%-%Seconds%
) else (
	set new_file_name=assembleFOSSID_%FWVER%_#%BUILD_NUMBER%_%Year%-%Month%-%Day%_%Hours%-%Minutes%-%Seconds%
)

rename .\..\..\..\..\..\..\Test_System\FOSSID\assembles\assemble.zip "%new_file_name%.zip"
if %ERRORLEVEL% NEQ 0 (	set ASSEMBLE_ERR=1 )

if %ASSEMBLE_ERR% NEQ 0 ( GOTO error )

:success
	:: Success
	COLOR A0
	exit /B 0

:error
	:: Error
	COLOR C0
	exit /B 1

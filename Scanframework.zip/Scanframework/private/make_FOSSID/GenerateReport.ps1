# Manadatory parameter to run this script are:
# $ScanCode - This is the Scan Code of BSP project
# $force - Disabling force to avoid prompting during run time
Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$ScanCode,
   [switch]$force = $false
)

# Headers required to run the WebApp API
$headers = @{}
$headers.Add("ContentType", "application/zip")

# URL to login to FOSSID DC Instance
$urlp= "https://rb-fossid.de.bosch.com/DC/api.php"

# Decrypt Password and Username
$bytesUser = Get-Content $pwd\username.sec
$bytesKey = Get-Content $pwd\password.sec
$username = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $bytesUser)))
$key = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $bytesKey)))

# Creating the report name to store the scan report
$ReportName = $ScanCode.Split("_")[3]

# Calling Generate Report API
Write-Host "`nGenerating Report..."
$report_body = @{
					 group = "scans"
					 action = "generate_report"
					 data = @{username = $username ;
							  key = $key ;
							  scan_code = $ScanCode ;                               
							  report_type = "html";
							  selection_type = "include_all_licenses";
							  selection_view = "all";
							  disclaimer = "This is my report disclaimer"
							 }
				}| convertto-json

# Getting the response of Generate Report WebApp API
$response = Invoke-WebRequest -Method post -Uri $urlp -Body $report_body -Headers $headers
$responseobj = $response.Content

Write-Host "Generate Report WebApp API returns status Code :" $response.StatusCode
if($response.StatusCode -eq 200)
{
	try 
	{
		$responsejsonobj = ConvertFrom-Json $responseobj -ErrorAction Stop;
		$validJson = $true;
	} 
	catch 
	{
		$validJson = $false;
	}

	if ($validJson) 
	{
		Write-Host "Generate Report WebApp API call Failed!!"
		Write-Host "Error Message:"	$responsejsonobj.error
		exit 1
	} 
	else 
	{
		Write-Host "Generate Report WebApp API call worked fine"
	}
}
else
{	
	Write-Host "Generate Report WebApp API call Failed!!"
	exit 1
}
# Saving the FOSSID report in log folder
$responseobj | Out-File -FilePath ..\log\$ReportName.html
Write-Host "Generated report $ReportName.html"

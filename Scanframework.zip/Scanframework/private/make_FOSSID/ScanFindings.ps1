# Manadatory parameter to run this script are:
# $ScanCode - This is the Scan Code of BSP project
# $BASISFWVER - Basis firmware version for which the scan is being performed
# $force - Disabling force to avoid prompting during run time
Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$ScanCode,
   [Parameter(Mandatory=$True,Position=2)]
   [string]$BASISFWVER,
   [switch]$force = $false
)

# Headers required to run the WebApp API
$headers = @{}
$headers.Add("ContentType", "application/zip")

# URL to login to FOSSID DC Instance
$urlp= "https://rb-fossid.de.bosch.com/DC/api.php"

# Decrypt Password and Username
$bytesUser = Get-Content $pwd\username.sec
$bytesKey = Get-Content $pwd\password.sec
$username = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $bytesUser)))
$key = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $bytesKey)))

# Fetching the Scan Findings
$ScanProjectName = $ScanCode.Split("_,-")[3]

Write-Host "`nScan Findings for $ScanCode..."
$metrics_body = @{
					 group = "scans"
					 action = "get_folder_metrics"
					 data = @{username = $username;
							  key = $key;
							  scan_code = $ScanCode;
							  path = ""
							 }
				}| convertto-json

# Getting the response of the Scan Findings WebApp API
$response = Invoke-WebRequest -Method post -Uri $urlp -Body $metrics_body -Headers $headers
$responseobj = $response.Content | ConvertFrom-Json

# Assigning the path to .git folder encoded with base64 to 'path' field of 'get_folder_metrics' API
# The string '.git' is encoded as 'LmdpdA==' in base64
$metrics_body = $metrics_body | ConvertFrom-Json
$metrics_body.data.path = "LmdpdA=="
$metrics_body = $metrics_body | ConvertTo-Json

$responsegit = Invoke-WebRequest -Method post -Uri $urlp -Body $metrics_body -Headers $headers
$responsegitobj = $responsegit.Content | ConvertFrom-Json

Write-Host "Scan Findings WebApp API returns status Code :" $response.StatusCode
if((($response.StatusCode -eq 200) -and ($responseobj.status -eq 1)) -and (($responsegit.StatusCode -eq 200) -and ($responsegitobj.status -eq 1)))
{
	Write-Host "Scan Findings WebApp API call worked fine"
}
else
{	
	Write-Host "Scan Findings WebApp API call Failed!!"
	Write-Host "Error Message:"	$responseobj.error
	exit 1
}

# Storing the values of all the Scan Findings to the respective variables
# Subtracting the .git folder's count from overall AllFiles & WithoutMatches count to avoid warnings raised due to increase in files in .git folder
$allfiles = $responseobj.data.total - $responsegitobj.data.total
$markedAsIdentified = $responseobj.data.identified_files
$pendingIdentifications = $responseobj.data.pending_identification
$withoutMatches = $responseobj.data.without_matches - $responsegitobj.data.without_matches

# Printing the count of all the Scan Findings
Write-Host "`tAll files count :" $allfiles
Write-Host "`tPending Identification files count:" $pendingIdentifications
Write-Host "`tMarked as Identified files count :" $markedAsIdentified
Write-Host "`tWithout matches files count:" $withoutMatches

# Comparing the values of Scan Findings with the baseline values
$Path = ".\baseline.xml"

[xml]$XmlDoc = Get-Content $Path

$parentnode = $XmlDoc.Findings.$BASISFWVER.Project | where {$_.name -eq $ScanCode}

# Storing the baseline values to the respective variables
$allfiles_Base = $parentnode.AllFiles
$pendingIdentifications_Base = $parentnode.PendingIdentifications
$markedAsIdentified_Base = $parentnode.MarkedasIdentified
$withoutMatches_Base = $parentnode.WithoutMatches

$errorcount = 0
$warningcount = 0
$err=0

# Mismatch in AllFiles count or WithoutMatches count, trigger warning
# Mismatch in PendingIdentifications count or MarkedAsIdentified count, trigger error
if($allfiles -ne $allfiles_Base)
{
  Write-Host "All files count is different from baseline, current value: " $allfiles " baseline value: "$allfiles_Base
  $warningcount = 1
  $err = 1
}
else
{
  Write-Host "All files count is same as baseline: "$allfiles
}

if($pendingIdentifications -ne $pendingIdentifications_Base)
{
  Write-Host "Pending Identifications count is different from baseline, current value: " $pendingIdentifications " baseline value: "$pendingIdentifications_Base
  $errorcount = 2
  $err = 3
}
else
{
  Write-Host "Pending Identifications count is same as baseline: "$pendingIdentifications
}

if($markedAsIdentified -ne $markedAsIdentified_Base)
{
  Write-Host "Marked as Identified count is different from baseline, current value: " $markedAsIdentified " baseline value: "$markedAsIdentified_Base
  $errorcount = 1
  $err = 2
}
else
{
  Write-Host "Marked as Identified count is same as baseline: "$markedAsIdentified
}

if($withoutMatches -ne $withoutMatches_Base)
{
  Write-Host "Without Matches count is different from baseline, current value: " $withoutMatches " baseline value: "$withoutMatches_Base
  $warningcount = 2
  $err = 4
}
else
{
  Write-Host "Without Matches count is same as baseline: "$withoutMatches
}

if($BASISFWVER -eq "Develop") # Plotting scan findings graph only for scan projects with BASISFW Develop version [Skip for hotfix version]
{
	# Calling python script to generate CSV file to plot graph for scan findings
	& .\JUnitPlot.py 1 $ScanProjectName $allfiles $pendingIdentifications $markedAsIdentified $withoutMatches
	Start-Sleep -Seconds 1 # Intentional delay to ensure generation of the file
	
	# Checking if any error is returned from JUnitPlot.py script
	if(!([String]::IsNullOrWhiteSpace((Get-Content .\..\log\ErrorLog.txt))))
	{
		Get-Content .\..\log\ErrorLog.txt
		$script:err = "Generation of CSV file Failed!!"
		Write-Host "Generation of CSV file Failed so cannot Plot graph of Scan Findings for $ScanProjectName Scan Project!!"
	}
	else
	{
		Write-Host "Generation of CSV file Successful"
	}
	Start-Sleep -Seconds 1 # Intentional delay to ensure generation of the file
}

# Error Evaluation
if($err -ne 0)
{
	if($warningcount -ne 0)
	{
		Write-Host "`nWarning: Scan Findings{All files, Without Matches} different from baseline values!"
	}
	if($errorcount -ne 0)
	{
		Write-Host "`nError: Scan Findings{Pending Identifications, Marked as Identified} different from baseline values!!"
		Write-Host "Please check the FOSSID instance for further details"
	}

	if(($err -match "Generation of CSV file Failed!!") -or ($errorcount -ne 0))
	{
		exit 1
	}
}
else
{
	Write-Host "`nScan Findings same as baseline values."
}

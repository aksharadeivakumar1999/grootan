# Manadatory parameter to run this script are:
# $ScanCode - This is the Scan Code of BSP project
# $force - Disabling force to avoid prompting during run time
Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$ScanCode,
   [switch]$force = $false
)

# Headers required to run the WebApp API
$headers = @{}
$headers.Add("ContentType", "application/zip")

# URL to login to FOSSID DC Instance
$urlp= "https://rb-fossid.de.bosch.com/DC/api.php"

# Decrypt Password and Username
$bytesUser = Get-Content $pwd\username.sec
$bytesKey = Get-Content $pwd\password.sec
$username = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $bytesUser)))
$key = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $bytesKey)))

$ScanName = $ScanCode.Split("_")[3]

# Getting the Scan information
Write-Host "`nGetting Scan Information for $ScanName Project"
$info_body = @{
				 group = "scans"
				 action = "get_information"
				 data = @{username = $username;
						  key = $key;
						  scan_code = $ScanCode
						 }
			}| convertto-json

# Getting the response of Scan Information WebApp API
$response = Invoke-WebRequest -Method post -Uri $urlp -Body $info_body -Headers $headers
$responseobj = $response.Content| ConvertFrom-Json

Write-Host "Scan Information WebApp API return value for" $ScanCode ":" $response.StatusCode
if(($response.StatusCode -eq 200) -and ($responseobj.status -eq 1))
{
	Write-Host "Scan Information WebApp API call worked fine"
}
else
{	
	Write-Host "Scan Information WebApp API call Failed!!"
	Write-Host "Error Message:"	$responseobj.error
	exit 1
}

Write-Host "Scan Information for $ScanCode project:"
$responseobj.data

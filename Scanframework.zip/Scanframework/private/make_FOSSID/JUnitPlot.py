import sys
import csv
from junit_xml import TestSuite, TestCase

# The parameters for generating JUnit XML file:
# sys.argv[1] - inputSwitch = 0 : Switch to generate JUnit XML file
# sys.argv[2] - Scan Project Name
# sys.argv[3] - Scan log consisting of scanned data for a specified scan project

# The parameters for generating CSV file:
# sys.argv[1] - inputSwitch = 1 : Switch to generate CSV file
# sys.argv[2] - Scan Project Name
# sys.argv[3] - Count of All Files
# sys.argv[4] - Count of Pending Idenification
# sys.argv[5] - Count of Marked As Identified
# sys.argv[6] - Count of Without Matches

with open('.\..\log\ErrorLog.txt', 'w') as err:
    try:
        # Checking if the required arguments are being passed
        Argslist = len(sys.argv)

        # Switch to choose between generation of JUnit XML file and CSV file
        inputSwitch = int(sys.argv[1])

        # Generating JUnit XML file for Test Result Trend graph
        if inputSwitch == 0:
            if Argslist != 4:
                print('JUnit XML Error: Required arguments not passed for generation of JUnit XML file..Exiting!!', file=err)
                raise SystemExit("JUnit XML Error: Required arguments not passed for generation of JUnit XML file..Exiting!!")

            # Reading the scan log of scan project and printing it as system-out
            with open(sys.argv[3], 'r') as f:
                contents = f.read()

            # Checking for error statements if any
            with open(sys.argv[3], 'r') as f:
                for data in f:
                    if "Error:" in data:
                        arr = data
                        break
                    elif "Error Message:" in data:
                        arr = data
                        break                    
                    else:
                        arr = None

            # Test case for Scan Log
            test_cases = TestCase('ScanLog_' + sys.argv[2], sys.argv[2], None, contents, arr)

            # Using 'add_error_info()' function to update the JUnit XML file with the error found in scan project.
            # This function logs the error from any respective batch or powershell scripts into the JUnit XML file in order to display build failure test result trend.
            if arr != None:
                print('JUnit XML: Error found in ' + sys.argv[2] + ' Scan Project, logged it in JUnit XML file to display build failure test result trend', file=err)
                test_cases.add_error_info(arr)

            # Adding test cases to test suite
            test_suite = TestSuite("Scan", [test_cases])

            # Writing JUnit XML to a file
            with open('.\..\log\ScanLog_' + sys.argv[2] + '.xml', 'w') as f:
                TestSuite.to_file(f, [test_suite], True, 'utf-8')

        # Generating CSV file to Plot Scan Findings graph
        if inputSwitch == 1:
            if Argslist != 7:
                print('CSV File Error: Required arguments not passed for generation of CSV file..Exiting!!', file=err)
                raise SystemExit("CSV File Error: Required arguments not passed for generation of CSV file..Exiting!!")

            # List of arguments and their values to be plotted
            row_list = [["AllFiles", "PendingIdentifcation", "MarkedAsIdentified", "WithoutMatches"],
                     [sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]]]

            # Writing the values in the row_list to "plot-ScanFindings_ScanName.csv" file
            with open('.\..\..\plot-ScanFindings_' + sys.argv[2] + '.csv', 'w') as file:
                writer = csv.writer(file)
                writer.writerows(row_list)
    except Exception as e:
        print(repr(e), file=err)

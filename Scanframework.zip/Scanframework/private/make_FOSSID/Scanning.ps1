# Manadatory parameter to run this script are:
# $BASISFWVER - Basis firmware version for which the scan is being performed
# $force - Disabling force to avoid prompting during run time
Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$BASISFWVER,
   [switch]$force = $false
)

# Fetching the Basis Firmware version used for scanning
$BasisFWCDFPath = "..\..\cdf.xml"
[xml]$BasisFWXmlDoc = Get-Content $BasisFWCDFPath
Write-Host "Scanning the projects for IC_BASISFW" $BASISFWVER "Version:" $BasisFWXmlDoc.cdf.Dependencies.DependsOn.Version

# Fetching the ScanCodes.xml file
$Path = ".\ScanCodes.xml"
[xml]$XmlDoc = Get-Content $Path

# Fetching the cdf.xml file
$CdfPath = "..\..\..\IC_BASISFW\cdf.xml"
[xml]$CdfXmlDoc = Get-Content $CdfPath

# Parsing Scan Codes of all the Scan Projects stored in ScanCodes.xml and passing it to ScanProject.bat batch file for scanning
$allnodes = $XmlDoc.Scan_Projects.$BASISFWVER.ChildNodes
foreach($node in $allnodes)
{
	$ScanCode = $node.Code
	$ScanName = $node.Name
	$ReuseScanCode = $node.SpecificScanCode
	$ScanProjectName = $ScanCode.Split("_,-")[3]
	Write-Host "`nStarting Scan for $ScanName Project"
	
	# Fetching the version for each of the Scan Projects
	$BSPnode = $CdfXmlDoc.cdf.Dependencies.DependsOn | where {$_.name -eq $node.BSPName}
	$Ver = -join($node.BSPName, "_", $BSPnode.Version)
	Write-Host "Version of" $node.BSPName ":" $Ver
	
	# Checking if the "Code" & "SpecificScanCode" attributes in ScanCodes.xml are empty
	if($ScanCode -eq "")
	{	
		$script:Err = "Scan Code is missing"
		Write-Host "Scan Code for $ScanName Project is missing!!`nScanning $ScanName Project Failed!!"
	}
	elseif($ReuseScanCode -eq "")
	{	
		$script:Err = "Specific Scan Code is missing"
		Write-Host "Specific Scan Code for $ScanName Project is missing!!`nScanning $ScanName Project Failed!!"
	}
	else
	{		
		if($ReuseScanCode -eq "NULL")   # This case is for HCQ02 BSP project because we don't have a reference scan project 
		{
			Write-Host "Scanning $ScanCode Project without using identifications from any scan"
		}
		else
		{
			Write-Host "Scanning Project $ScanCode using the identifications from $ReuseScanCode"
		}
		
		# Create log folder if it doesn't exist
		if(!(Test-Path -Path ..\log)) { New-Item ..\log -Type Directory }
		
		# Calling the ScanProject.bat file for running all the WebApp APIs
		# Generating text file with ANSI encoding because powershell generates a text file in BOM format [Byte Order Mark] and this format is not accepted by python
		& .\ScanProject.bat $ScanCode $ReuseScanCode $BASISFWVER | Out-File -encoding ASCII .\..\log\ScanLog_$ScanProjectName.txt 2>&1
		if($LASTEXITCODE -ne 0)
		{
			Get-Content .\..\log\ScanLog_$ScanProjectName.txt
			$script:Err = "Scanning the project Failed"
			Write-Host "Scanning $ScanName Project Failed!!"
		}
		else
		{
			Get-Content .\..\log\ScanLog_$ScanProjectName.txt
			Write-Host "Scanning $ScanName Project Successful!!"
		}
		
		# Calling python script to generate JUnit XML to view test result trend
		& .\JUnitPlot.py 0 $ScanProjectName .\..\log\ScanLog_$ScanProjectName.txt
		Start-Sleep -Seconds 1 # Intentional delay to ensure generation of the file
		
		# Checking if any error is returned from JUnitPlot.py script
		if(!([String]::IsNullOrWhiteSpace((Get-Content .\..\log\ErrorLog.txt))))
		{
			# Print logs of JUnitPlot.py script are present in ErrorLog.txt file. Outputting the logs to console
			Get-Content .\..\log\ErrorLog.txt
			
			# Checking if a part of "JUnit XML: Error found in any Scan Project, logged it in JUnit XML file to display build failure test result trend" logline
			# is present in 'ErrorLog.txt' file. This logline is not an error from JUnitPlot.py script, but it's an information of error being found in any batch
			# or powershell scripts. In this case, JUnit XML file is generated successfully irrespective of error being logged in the JUnit XML.
			if(Get-Content .\..\log\ErrorLog.txt | Select-String -Pattern "JUnit XML: Error found in")
			{
				Write-Host "Generation of JUnit XML file Successful"
			}
			else
			{
				$script:Err = "Generation of JUnit XML file Failed!!"
				Write-Host "Generation of JUnit XML file Failed so cannot display test result trend for $ScanProjectName Scan Project!!"
			}
		}
		else
		{
			Write-Host "Generation of JUnit XML file Successful"
		}
		Start-Sleep -Seconds 1 # Intentional delay to ensure generation of the file
		Remove-Item .\..\log\*.txt
	}
}

# Error Evaluation
if($Err -ne $null)
{
	exit 1
}
else
{
	exit 0
}

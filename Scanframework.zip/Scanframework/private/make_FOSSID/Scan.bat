@echo off
REM ---FWVER Parameter needs to be set to Develop/Hotfix14V22/Hotfix15V10 in Jenkins Configuration---

set SCRIPTERR=0

REM ---Cleanup (Deleting the existing files in log folder)---
if not exist ..\log (
 mkdir ..\log
)
del ..\log\* /s /q

REM ---Fetching the BASISFW Version---
call reset_dependencies.bat
IF %ERRORLEVEL% NEQ 0 ( exit /B 1)

REM ---Calling the PowerShell script for entire Scan Automation Process---
echo.
echo Starting the Scan process...
powershell %cd%\Scanning.ps1 %FWVER%
if %ERRORLEVEL% NEQ 0 ( 
 set SCRIPTERR=1 
 echo Scanning Failed for one or more projects!!
) else (
 echo Scanning for all the Scan Projects Successful...
)

REM ---Assembling the FOSSID Reports in a specific place---
echo.
echo Copying and zipping all the FOSSID reports...
call %cd%\assembleFOSSID.bat
if %ERRORLEVEL% NEQ 0 (
 set SCRIPTERR=1
 echo ERROR, Assembling the FOSSID Reports Failed!!
) else (
 echo Assembling the FOSSID Reports Successful...
)

REM ---Error Evaluation---
if %SCRIPTERR% NEQ 0 (
echo ERROR, Scan completed with errors!!
) else ( 
echo Scan completed without errors...
)

REM ---Create directory to save the Jenkins Console Output---
if not exist .\..\..\..\..\..\..\Test\Jenkins_ConsoleOp\%JOB_NAME% (
mkdir .\..\..\..\..\..\..\Test\Jenkins_ConsoleOp\%JOB_NAME%
)

REM ---Saving the Jenkins Console Output---
curl -L --insecure %BUILD_URL%consoleText > %JOB_NAME%_#%BUILD_NUMBER%.txt
if %ERRORLEVEL% NEQ 0 (
 echo Saving the Jenkins Console Output in a text file Failed!!
 exit /B 1
)

copy %JOB_NAME%_#%BUILD_NUMBER%.txt .\..\..\..\..\..\..\Test\Jenkins_ConsoleOp\%JOB_NAME%
del %JOB_NAME%_#%BUILD_NUMBER%.txt

REM ---Error Evaluation---
if %SCRIPTERR% NEQ 0 (
 goto error
)

:success
	:: Success	
	COLOR A0
	exit /B 0

:error
	:: Error
	COLOR C0
	exit /B 1
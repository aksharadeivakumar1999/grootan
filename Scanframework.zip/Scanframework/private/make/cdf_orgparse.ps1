$Path = "..\..\cdf.xml"

[xml]$XmlDoc = Get-Content $Path

$parentnode = $XmlDoc.cdf.Dependencies.DependsOn 

if($parentnode.name -eq  "appBuildBuddy")
{
	$node = $XmlDoc.cdf.Dependencies.DependsOn |where {$_.name -eq "appBuildBuddy"}
	$XmlDoc.cdf.Dependencies.RemoveChild($node)
	if ($? -eq 0)
    {
		$script:Err = "Failed to remove appBuildBuddy node"
	}
}

if($parentnode.name -eq  "appTestBuddy")
{
	$node = $XmlDoc.cdf.Dependencies.DependsOn |where {$_.name -eq "appTestBuddy"}
	$XmlDoc.cdf.Dependencies.RemoveChild($node)
	if ($? -eq 0)
	{
		$script:Err = "Failed to remove appTestBuddy node"
	}
}

if($parentnode.name -eq  "IC_BspHeader")
{
	$node = $XmlDoc.cdf.Dependencies.DependsOn |where {$_.name -eq "IC_BspHeader"}
	$XmlDoc.cdf.Dependencies.RemoveChild($node)
	if ($? -eq 0)
	{
		$script:Err = "Failed to remove IC_BspHeader node"
	}
}

if($parentnode.name -eq  "IC_XM1x_BSP")
{
	$node = $XmlDoc.cdf.Dependencies.DependsOn |where {$_.name -eq "IC_XM1x_BSP"}
	$XmlDoc.cdf.Dependencies.RemoveChild($node)
	if ($? -eq 0)
	{
		$script:Err = "Failed to remove IC_XM1x_BSP node"
	}
}

if($parentnode.name -eq  "IC_BR_WEB_SVR")
{
	$node = $XmlDoc.cdf.Dependencies.DependsOn |where {$_.name -eq "IC_BR_WEB_SVR"}
	$XmlDoc.cdf.Dependencies.RemoveChild($node)
	if ($? -eq 0)
	{
		$script:Err = "Failed to remove IC_BR_WEB_SVR node"
	}
}

$Allnodes = $XmlDoc.cdf.Dependencies.ChildNodes
foreach($node in $Allnodes)
{
	$node.FromRepository = "Source"
	if($node.PreRelease -eq "develop.*")
	{
		Write-Host "Prerelease attribute found for"$node.name", changing the version to develop"
		$node.RemoveAttribute('PreRelease')
		$node.Version = "develop"
	}

	elseif($node.PreRelease -Match "hotfix*")
	{
		$PrereleaseVer = $node.PreRelease.Split('x')[1].Split('.')[0]
		$node.Version = "hotfix/$PrereleaseVer"
		if ($? -eq 0)
		{
			$script:ERR = "Failed to change Version attribute to hotfix/$PrereleaseVer"
		}
		Write-Host "Prerelease attribute found for"$node.name", changing the version to hotfix/$PrereleaseVer"
		
		$node.RemoveAttribute('PreRelease')
		if ($? -eq 0)
		{
			$script:ERR = "Failed to remove PreRelease atrribute"
		}
	}
	
	else
	{
		Write-Host "Prerelease attribute not found for"$node.name""	
	}
}

$XmlDoc.Save($Path)
if ($? -eq 0)
{
	$script:Err = "Failed to save cdf.xml"
}

if ($Err -ne $null)
{
	Write-Host $ERR
	Write-Host "Error: Parsing the cdf.xml file failed!!!"
    exit 1
}
else
{
	Write-Host "Parsing the cdf.xml file Succesful"
	exit 0
} 

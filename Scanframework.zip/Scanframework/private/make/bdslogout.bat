
call bdstool logout
IF %ERRORLEVEL% NEQ 0 ( exit /B 1 )

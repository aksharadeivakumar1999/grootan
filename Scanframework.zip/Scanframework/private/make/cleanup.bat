@echo off
cd /d %~dp0

if not exist *.log (
echo No previous BDS log files 
)

if exist *.log (
echo Deleting the earlier BDS log files
del *.log 
)
IF %ERRORLEVEL% NEQ 0 ( exit /B 1 )

@echo off

:: call powershell script to login in bdstool with encrypted password and usernam

powershell %BDSHOMEPATH%\bdslogin.ps1 

IF %errorlevel% NEQ 0 ( echo Error: Execution of login powershell script failed
exit /B 1 ) ELSE (
echo Execution of login powershell script successful
)

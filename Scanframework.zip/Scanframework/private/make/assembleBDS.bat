set filepath=%BDSLOGSTORE%\assembles
set assemblefile= assembleBDS_%Year%-%Month%-%Day%_%Hours%-%Minutes%
set ASSEMBLE_ERR=0

REM --- Get date 
FOR /F "tokens=1-3 delims=/." %%A IN ("%Date%") DO (
    SET Day=%%A
    SET Month=%%B
    SET Year=%%C
)
REM --- Get time
FOR /F "tokens=1-3 delims=/:, " %%A IN ("%Time%") DO (
    SET Hours=%%A
    SET Minutes=%%B
    SET Seconds=%%C
)
REM --- add a leading zero
set Hours=%TIME:~0,2%
IF "%TIME:~0,1%" EQU " " ( SET Hours=0%Hours:~1,1%)

if exist %BDSLOGSTORE%\logs rmdir %BDSLOGSTORE%\logs /s /q 
mkdir %BDSLOGSTORE%\logs
IF %ERRORLEVEL% NEQ 0 (SET ASSEMBLE_ERR=1)

REM copy ..\*_History.txt ..\..\public
copy %BDSLOGPATH%\BDSLOG_*.log %BDSLOGSTORE%\logs /Y
IF %ERRORLEVEL% NEQ 0 (SET ASSEMBLE_ERR=1)

set assemblefile=assembleBDS_%FWVER%_%Year%-%Month%-%Day%_%Hours%-%Minutes%-%Seconds%
7z a "%filepath%\%assemblefile%.zip" %BDSLOGSTORE%\logs\*
IF %ERRORLEVEL% NEQ 0 (SET ASSEMBLE_ERR=1)

IF %ASSEMBLE_ERR% NEQ 0 ( exit /B 1 )

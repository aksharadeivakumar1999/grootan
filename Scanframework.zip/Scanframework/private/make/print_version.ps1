Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$prjname,
   [switch]$force = $false
)

$Path = "..\..\..\IC_BASISFW\cdf.xml"
[xml]$XmlDoc = Get-Content $Path
$node = $XmlDoc.cdf.Dependencies.DependsOn |where {$_.name -eq "$prjname"}
$version = $node.Version
Write-Host "Version of"$prjname": "$prjname"_"$version""

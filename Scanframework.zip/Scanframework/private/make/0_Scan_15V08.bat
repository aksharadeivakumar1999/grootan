REM for Blackduck_project_id:
REM bdstool --server rb-oss-protex-22.bosch.com --user <username> --password <password> login
REM bdstool list-projects
REM OUTPUT:
REM project id                  project label (and version)
REM ----------                 ---------------------------
REM c_dc__ehe6_brbspapi_6898 		DC__EHE6_BRBSPAPI
REM c_dc__ehe6_brextmod_6970 		DC__EHE6_BREXTMOD
REM c_dc__ehe6_xm21-bsp_6685 		DC__EHE6_XM21-BSP
REM c_dc__ehe6_xm4x-bsp_6728 		DC__EHE6_XM4x-BSP
REM c_dc__ehe6_pr41-bsp_6642 		DC__EHE6_PR41-BSP

set BDSSOURCEFILEPATH=..\..\..
set BDSHOMEPATH=%CD%
set BDSLOGPATH=%BDSHOMEPATH%
set BDSLOGSTORE=D:\Test_System\BDS
REM USER: bat9er
set BDSPWFILE=%BDSHOMEPATH%\password.sec
set BDSUNFILE=%BDSHOMEPATH%\username.sec
set SCRIPTERR=0

if not exist ..\..\cdf.xml (
echo cdf.xml file does not exist!!
exit /B 1 
)
echo cdf.xml file exist

call reset_dependencies.bat
IF %ERRORLEVEL% NEQ 0 ( exit /B 1)

cd ..\..
copy cdf.xml cdf_Scan.bak
IF %ERRORLEVEL% NEQ 0 ( SET SCRIPTERR=1)
del cdf.xml
IF %ERRORLEVEL% NEQ 0 ( SET SCRIPTERR=1)
copy ..\IC_BASISFW\cdf.xml cdf.xml 
IF %ERRORLEVEL% NEQ 0 ( SET SCRIPTERR=1)
cd private\make

powershell %CD%\cdf_orgparse.ps1
IF %ERRORLEVEL% NEQ 0 ( exit /B 1)

call reset_dependencies.bat
IF %ERRORLEVEL% NEQ 0 ( exit /B 1)

cd ..\..
del cdf.xml
IF %ERRORLEVEL% NEQ 0 ( SET SCRIPTERR=1)
copy cdf_Scan.bak cdf.xml
IF %ERRORLEVEL% NEQ 0 ( SET SCRIPTERR=1)
del cdf_Scan.bak
cd private\make

echo Cleaning the previous log files
call %BDSHOMEPATH%\cleanup.bat
IF %ERRORLEVEL% NEQ 0 (
echo error: Cleanup not successful
exit /B 1
) ELSE (
echo Cleanup done
)

echo Logging in to Protex server
call %BDSHOMEPATH%\bdslogin.bat
IF %ERRORLEVEL% NEQ 0 (
echo Error: Login failed
exit /B 1
) ELSE (
echo Login successful
)
echo.
echo Starting the Scan process...
	
call %BDSHOMEPATH%\scanProject.bat %BDSSOURCEFILEPATH%\IC_BR_BSPAPI\private c_dc__ehe6_brbspapi_6898 DC__EHE6_BRBSPAPI IC_BR_BSPAPI
IF %ERRORLEVEL% NEQ 0 ( echo Error: Scanning failed for ic_br_bspapi 
                        SET SCRIPTERR=1 )

call %BDSHOMEPATH%\scanProject.bat %BDSSOURCEFILEPATH%\IC_BR_EXTMOD\private c_dc__ehe6_brextmod_6970 DC__EHE6_BREXTMOD IC_BR_EXTMOD
IF %ERRORLEVEL% NEQ 0 ( echo Error: Scanning failed for ic_br_extmod 
                       SET SCRIPTERR=1 )

call %BDSHOMEPATH%\scanProject.bat %BDSSOURCEFILEPATH%\IC_XM21_BSP\private\projects c_dc__ehe6_xm21-bsp_6685 DC__EHE6_XM21-BSP IC_XM21_BSP
IF %ERRORLEVEL% NEQ 0 ( echo Error: Scanning failed for ic_xm21_bsp 
                        SET SCRIPTERR=1 )

call %BDSHOMEPATH%\scanProject.bat %BDSSOURCEFILEPATH%\IC_XM4x_BSP\private\projects c_dc__ehe6_xm4x-bsp_6728 DC__EHE6_XM4x-BSP IC_XM4x_BSP
IF %ERRORLEVEL% NEQ 0 ( echo Error: Scanning failed for ic_xm4x_bsp 
                        SET SCRIPTERR=1 )

call %BDSHOMEPATH%\scanProject.bat %BDSSOURCEFILEPATH%\IC_PR41_BSP\private\projects c_dc__ehe6_pr41-bsp_6642 DC__EHE6_PR41-BSP IC_PR41_BSP
IF %ERRORLEVEL% NEQ 0 ( echo Error: Scanning failed for ic_pr41_bsp 
                        SET SCRIPTERR=1 )
echo.
echo Checking if Scan logs have errors
call %BDSHOMEPATH%\error_detect.bat 
IF %ERRORLEVEL% NEQ 0 ( SET SCRIPTERR=1)

echo.						
echo Logging out of Protex server
call %BDSHOMEPATH%\bdslogout.bat
IF %ERRORLEVEL% NEQ 0 (
echo error: logout not successful
exit /B 1
) ELSE (
echo Logout successful
)

echo.
echo Copying and  zipping all the BDS log files 
call %BDSHOMEPATH%\assembleBDS.bat
IF %ERRORLEVEL% NEQ 0 (
echo error: Assembling not successful
exit /B 1
) ELSE (
echo Assembling successful
)

IF %SCRIPTERR% NEQ 0 (
echo Error: Scan completed with errors!! 
) ELSE ( 
echo Scan completed without errors.
)

REM ---Switching from C: to D: drive to save the Jenkins Console Output in a text file---
cd /d %BDSHOMEPATH%

REM ---Create directory to save the Jenkins Console Output---
if not exist .\..\..\..\..\..\..\Test\Jenkins_ConsoleOp\%JOB_NAME% (
mkdir .\..\..\..\..\..\..\Test\Jenkins_ConsoleOp\%JOB_NAME%
)

REM ---Saving the Jenkins Console Output---
curl -L --insecure %BUILD_URL%consoleText > %JOB_NAME%_#%BUILD_NUMBER%.txt
if %ERRORLEVEL% NEQ 0 (
 echo Saving the Jenkins Console Output in a text file Failed!!
 exit /B 1
)

copy %JOB_NAME%_#%BUILD_NUMBER%.txt .\..\..\..\..\..\..\Test\Jenkins_ConsoleOp\%JOB_NAME%
del %JOB_NAME%_#%BUILD_NUMBER%.txt

REM ---Error Evaluation---
IF %SCRIPTERR% NEQ 0 (
 exit /B 1
)
exit /B 0


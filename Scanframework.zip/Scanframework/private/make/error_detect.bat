setlocal ENABLEDELAYEDEXPANSION
@echo off
cd /d %~dp0
SET ERR=0

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_BRBSPAPI.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_BRBSPAPI.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_br_bspapi Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_BREXTMOD.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_BREXTMOD.log
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_br_extmod Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_FuncMod.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_FuncMod.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_funcmod Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_CML25-BSP.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_CML25-BSP.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_cml25_bsp Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_CML65-BSP.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_CML65-BSP.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_cml65_bsp Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_CML75-BSP.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_CML75-BSP.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_cml75_bsp Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_CML85-BSP.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_CML85-BSP.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_cml85_bsp Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_HCQ02-BSP.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_HCQ02-BSP.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_hcq02_bsp Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_XM21-BSP.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_XM21-BSP.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_xm21_bsp Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_XM4x-BSP.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_XM4x-BSP.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_xm4x_bsp Project
                        SET ERR=1 )
)

if exist %BDSHOMEPATH%\BDSLOG_DC__EHE6_PR41-BSP.log (
echo.
powershell %BDSHOMEPATH%\error_detect.ps1 %BDSHOMEPATH%\BDSLOG_DC__EHE6_PR41-BSP.log 
IF !ERRORLEVEL! NEQ 0 ( echo Error found in Scan Log of ic_pr41_bsp Project
                        SET ERR=1 )
)	
	
echo.	
IF %ERR% NEQ 0 ( echo Error found in the Scan Log files
exit /B 1
) ELSE ( 
echo No errors found in the Scan Log files
)

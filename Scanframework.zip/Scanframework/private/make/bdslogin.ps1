# read Password and Username
$bytesPwd = Get-Content $Env:BDSPWFILE
$bytesUN = Get-Content $Env:BDSUNFILE

# decrypt Password and Username
$password = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR( (ConvertTo-SecureString $bytesPwd) ))
$username = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR( (ConvertTo-SecureString $bytesUN) ))

# Login 
# bdstool --server https://rb-oss-protex-1.bosch.com/ --user $username --password $password login

bdstool --server https://rb-oss-protex-22.bosch.com/ --user $username --password $password login

if ($LASTEXITCODE -eq 0) {
    Write-Host "Login to protex server is successful"
	exit 0
    }
    else {
    Write-Host "Error: Login to protex server failed!!!"
	exit 1
    }
	
Param(
   [Parameter(Mandatory=$True,Position=1)]
   [string]$path,
   [switch]$force = $false
)
$pattern = ','

#Finding if there are any error statements
$ERR = Select-String -Path $path -Pattern "ERROR:"

#Finding number of info, warning and errors
Select-String -Path $path -Pattern "Logged messages by severity:" -SimpleMatch | ForEach-Object {
	$splitstring = $_.Line.Split($pattern,[System.StringSplitOptions]::RemoveEmptyEntries)
	$infoln = $splitstring[0]
	$warningln = $splitstring[1]
	$errorln = $splitstring[2]
	Write-Host "Findings for"$path.Split('\')[7]""
	$info = $infoln.Split(':')[1].Split(' ')[1]
	Write-Host "No. of Information found:"$info""

	$warning = $warningln.Split(' ')[1]
	Write-Host "No. of Warnings found:"$warning""

	if ($errorln -ne $null)
	{
		$error = $errorln.Split(' ')[1]
		Write-Host "No. of errors found:"$error""
	}
	else
	{
		Write-Host "No errors found"
	}
 }

if ($ERR -ne $null)
{
	Write-Host "Error found in log"
	Write-Host $ERR	
    exit 1
}
else
{
	# checking if there were any errors found
	if ($error -ne $null)
	{
		Write-Host "Errors associated with warnings, can be ignored."
		exit 0
	}
	else 
	{
		exit 0
	}
}

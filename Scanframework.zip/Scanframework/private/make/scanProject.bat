@echo off
cd /d %~dp0

SET SCANERR=0
set SOURCEPATH=%1
set PROJECTID=%2
set PROJECTNAME=%3

echo.
echo Checking if %PROJECTNAME% project exists
if not exist %SOURCEPATH% ( echo Project doesnot exist in %SOURCEPATH%!!
exit /B 1 
)
echo Project exists
powershell %BDSHOMEPATH%\print_version.ps1 %4
IF %ERRORLEVEL% NEQ 0 ( echo Print Version failed!!
SET SCANERR=1)

echo Starting the BDSLog for the project %PROJECTNAME% 
echo ####START %PROJECTNAME%  ###### %DATE% %TIME% ######### >> %BDSLOGPATH%\BDSLOG_%PROJECTNAME%.log

echo Substituting the source project, %Projectname% to v drive
if exist v:\NUL subst v: /D
subst v: %SOURCEPATH%
IF %ERRORLEVEL% NEQ 0 ( SET SCANERR=1)
ping -n 4 localhost

v:
echo Executing the bds tool commands for the project
call bdstool new-project %PROJECTID% --verbose >> %BDSLOGPATH%\BDSLOG_%PROJECTNAME%.log
IF %ERRORLEVEL% NEQ 0 ( SET SCANERR=1)

echo Starting the analysis of the project %Projectname% 
call bdstool analyze --force --verbose >> %BDSLOGPATH%\BDSLOG_%PROJECTNAME%.log
IF %ERRORLEVEL% NEQ 0 ( SET SCANERR=1)

subst v: /d
IF %ERRORLEVEL% NEQ 0 ( SET SCANERR=1)

c:
echo. >> %BDSLOGPATH%\BDSLOG_%PROJECTNAME%.log
echo #####END %PROJECTNAME%  ###### %DATE% %TIME% ######### >> %BDSLOGPATH%\BDSLOG_%PROJECTNAME%.log
echo. >> %BDSLOGPATH%\BDSLOG_%PROJECTNAME%.log

IF %SCANERR% NEQ 0 (
echo Error in executing scan of %Projectname%
exit /B 1
) ELSE ( 
echo Scan for %Projectname% is successful
)

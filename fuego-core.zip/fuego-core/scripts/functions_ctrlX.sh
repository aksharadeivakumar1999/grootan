
function switchstate {
    STATE=$1
    echo -e "\n=== STATE: $STATE ===\n"
}

function check_connection {
    unset http_proxy
    unset https_proxy
    unset HTTP_PROXY
    unset HTTPS_PROXY

    switchstate LOGIN

    # Timeout in 10min
    i=120
    while [ $i -gt 0 ]; do
        case $STATE in
            LOGIN)
                resp=$(curl -s -w "%{http_code}" -k -X POST -H "Content-Type: application/json" \
                        -d '{"name":"boschrexroth","password":"boschrexroth"}' \
                        https://$DEVICE/identity-manager/api/v1/auth/token 2>/dev/null)

                result="$?"
                http_code=$(echo -n $resp | tail -c 3)
                if [ "$result" -eq "0" ] && [ "$http_code" -eq "201" ]; then
                    TOKEN=$(echo "$resp" | sed -n 's|.*"access_token":.*"\([^"]*\)".*|\1|p')
                    switchstate FINISHED
                    continue
                else
                    echo -n .
                fi
                ;;
            FINISHED)
                return 0
                ;;
            FAILED)
                return 1
                ;;
        esac
        sleep 5
        i=$(( i - 1 ))
    done
    echo -e "\n=== TIMEOUT ===\n"
}

function check_rescuesystem_connection_after_update {
    
    unset http_proxy
    unset https_proxy
    unset HTTP_PROXY
    unset HTTPS_PROXY

    echo "DEVICE: $DEVICE"

    switchstate HEALTH

    # Timeout in 12min
    i=144
    while [ $i -gt 0 ]; do
        case $STATE in
            HEALTH)
                resp=$(curl -s -o /dev/null -w "%{http_code}" -k -X GET -H "Content-Type: application/json" http://192.168.1.1/firmmware 2>/dev/null)
                result="$?"
                if [ "$result" -eq "0" ] && [ "$resp" -eq "200" ]; then
                    echo
                    echo "rescue system has started completely"
                    switchstate FINISHED
                    continue
                else
                    echo -n .
                fi
                ;;
            FINISHED)
                return 0
                ;;
            FAILED)
                return 1
                ;;
        esac
            sleep 5
            i=$(( i - 1 ))
    done
    echo -e "\n=== TIMEOUT ===\n"
}

function check_connection_after_update {
    
    unset http_proxy
    unset https_proxy
    unset HTTP_PROXY
    unset HTTPS_PROXY

    INTERFACE_DEFAULT="${NET_INTERFACE_DEFAULT:-$'XF10'}"
    echo "ASSERTION_FILE: $ASSERTION_FILE"
    echo "DEVICE: $DEVICE"
    echo "INTERFACE_DEFAULT: ${INTERFACE_DEFAULT}"

    RELEASE_IMAGE=false
    switchstate HEALTH

    # Timeout in 20min (kbox)
    i=240
    # ssh loop counter
    j=0
    # upload assertion loop counter
    k=0
    while [ $i -gt 0 ]; do
        case $STATE in
            HEALTH)
                resp=$(curl -s -o /dev/null -w "%{http_code}" -k -X GET -H "Content-Type: application/json" https://$DEVICE/health 2>/dev/null)
                result="$?"
                if [ "$result" -eq "0" ] && [ "$resp" -eq "204" ]; then
                    echo
                    echo "device admin has started completely"
                    switchstate LOGIN
                    continue
                else
                    echo -n .
                fi
                ;;
            LOGIN)
                resp=$(curl -s -w "%{http_code}" -k -X POST -H "Content-Type: application/json" \
                        -d '{"name":"boschrexroth","password":"boschrexroth"}' \
                        https://$DEVICE/identity-manager/api/v1/auth/token 2>/dev/null)

                result="$?"
                http_code=$(echo -n $resp | tail -c 3)
                if [ "$result" -eq "0" ] && [ "$http_code" -eq "201" ]; then
                    TOKEN=$(echo "$resp" | sed -n 's|.*"access_token":.*"\([^"]*\)".*|\1|p')
                    switchstate CONFIGURE_CONNECTIVITY
                    continue
                else
                    echo -n .
                fi
                ;;
            CONFIGURE_CONNECTIVITY)
                # Configure Network Connectifity - delete default IP-address of XF10
                echo
                echo "Configure Network Connectivity"

                # get Network configuration
                resp=$(curl -s -k -X GET -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                    https://$DEVICE/network-manager/api/v1/interfaces/$INTERFACE_DEFAULT/configuration 2>/dev/null)
                
                echo "Network configuration before modification"
                echo $resp | jq .
                
                # change network configuration
                http_code=$(curl -s -o /dev/null -w "%{http_code}" -k -X PUT -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                    -d '{"disabled":false,"dhcp4":true,"ipv4Address":[],"dhcp6":true,"ipv6Address":[],"gateway4":"","gateway6":"","managed":true,"dhcpOptions":{"dhcpIdentifier":"rfc4361"}}' \
                    https://$DEVICE/network-manager/api/v1/interfaces/$INTERFACE_DEFAULT/configuration 2>/dev/null)
                
                if [ "$?" -ne "0" ] && [ "$http_code" -ne "204" ]; then      
                    echo  "Failed to modify Network configuration: $http_code."
                    switchstate FAILED
                    continue
                fi

                #apply changes
                http_code=$(curl -s -o /dev/null -w "%{http_code}" -k -X PUT -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                    -d '{"applied":true}' https://$DEVICE/network-manager/api/v1/changes 2>/dev/null)

                if [ "$?" -ne "0" ] && [ "$http_code" -ne "204" ]; then      
                    echo  "Failed to apply Network configuration: $http_code."
                    switchstate FAILED
                    continue
                else
                    # get Network configuration
                    resp=$(curl -s -k -X GET -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                        https://$DEVICE/network-manager/api/v1/interfaces/$INTERFACE_DEFAULT/configuration 2>/dev/null)
                
                    echo "Network configuration after modification"
                    echo $resp | jq .
                    switchstate CREATE_SU
                    continue
                fi
                ;;
            CREATE_SU)
                # Check if root user exist
                echo
                echo "Check if root user exist"
                resp=$(curl -s -k -X GET -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                    https://$DEVICE/identity-manager/api/v1/users 2>/dev/null)

                uid=$(echo $resp | jq -r '.[] | select(.name=="rexroot") | .id')
                if  [ -z "$uid" ] ; then
                    # root user not exist
                    echo
                    echo "root user not exist"
                    echo
                    echo "Upload system user assertion"
                    resp=$(curl -s -w "%{http_code}" -k -X POST -H "Content-Type: multipart/form-data" -H "Authorization: Bearer $TOKEN" \
                        -F "file=@$ASSERTION_FILE" \
                        https://$DEVICE/identity-manager/api/v1/systemusergen 2>/dev/null)
                    result="$?"
                    http_code=$(echo -n $resp | tail -c 3)
                    if  [ "$result" -eq "0" ] && [ "$http_code" -eq "201" ]; then                  
                        switchstate CHANGE_PWD
                        continue
                    else
                        k=$(( k + 1 ))
                        if [ $k -gt 100 ] ; then
                            echo "Failed to upload assertion: $http_code"
                            switchstate FAILED
                            continue
                        else
                            echo "Failed to upload assertion: $http_code"
                            echo "Try again -> loop #$k ..."
                        fi
                    fi
                else
                    # root user exist - continue
                    echo
                    echo "root user exist - continue"
                    switchstate CHECK_VERSION
                    continue
                fi
                ;;
            CHANGE_PWD)
                echo "update password policies"
                http_code=$(curl -s -o /dev/null -w "%{http_code}" -k -X PUT -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                    -d '{"minLen":1,"minLowercase":0,"minUppercase":0,"minDigit":0,"minSpecial":0,"rejectUsername":false,"remember":0,"expiresAfterDays":0}' \
                    https://$DEVICE/identity-manager/api/v1/policies/users/passwords 2>/dev/null)
                if [ "$?" -ne "0" ] && [ "$http_code" -ne "200" ]; then      
                    echo  "Failed to update password policies: $http_code."
                    switchstate FAILED
                    continue
                fi

                # Get users
                echo "Get uid of user"
                resp=$(curl -s -k -X GET -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                    https://$DEVICE/identity-manager/api/v1/users 2>/dev/null)

                uid=$(echo $resp | jq -r '.[] | select(.name=="rexroot") | .id')
                echo $uid

                echo
                echo "Change password of user"
                # Try to delete user rexroot
                http_code=$(curl -s -o /dev/null -w "%{http_code}" -k -X PUT -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                    -d '{"newPassword": "rexroot", "currentPassword": ""}' \
                    https://$DEVICE/identity-manager/api/v1/users/$uid/credentials 2>/dev/null)
                if [ "$?" -ne "0" ] && [ "$http_code" -ne "204" ]; then
                    echo  "Failed to change password: $http_code."
                    switchstate FAILED
                    continue
                fi

                echo "reset password policies"
                http_code=$(curl -s -o /dev/null -w "%{http_code}" -k -X PUT -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                    -d '{"minLen":12,"minLowercase":1,"minUppercase":1,"minDigit":1,"minSpecial":1,"rejectUsername":true,"remember":5,"expiresAfterDays":0}' \
                    https://$DEVICE/identity-manager/api/v1/policies/users/passwords 2>/dev/null)
                if [ "$?" -eq "0" ] && [ "$http_code" -eq "200" ]; then
                    switchstate CHECK_VERSION
                    continue              
                else
                    echo  "Failed to reset password policies: $http_code."
                    switchstate FAILED
                    continue
                fi
                ;;
            CHECK_VERSION)
                echo
                echo "check if release or develop image"
                 # check release or develop version of rexroth-deviceadmin
                resp=$(curl -s -k -X GET -H "accept: application/json" -H "Authorization: Bearer $TOKEN" \
                        "https://$DEVICE/package-manager/api/v1/packages/snap_rexroth-deviceadmin" 2>/dev/null )

                version=$(echo $resp | jq . | grep version | cut -d\" -f4)
                echo "Version of rexroth-deviceadmin -> $version"
                 if [ $(echo $version | grep develop) ] ; then
                    echo  "Develop image"
                    RELEASE_IMAGE=false
                else
                    echo "Release image"
                    RELEASE_IMAGE=true
                fi
                echo "Status of RELEASE_IMAGE=$RELEASE_IMAGE"
                switchstate ACTIVATE_SSH
                continue
                ;;
            ACTIVATE_SSH)
                echo
                echo "check if ssh is avtivated"
                # Get ssh status
                echo
                echo "Get ssh status"
                resp=$(curl -s -k -X GET -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" https://$DEVICE/ssh/api/v1/status 2>/dev/null)
                SSH_STATE=$(echo "$resp" | sed -n 's|.*"state":.*"\([^"]*\)".*|\1|p')
                echo "ssh state: $SSH_STATE"
                if [ -z "$SSH_STATE" ] ; then
                    echo
                    echo  "Failed to activate ssh."
                    switchstate FAILED
                    continue
                else
                    if [ "$SSH_STATE" = "activated" ] ; then
                        if [ $RELEASE_IMAGE = true ] ; then
                            # workaround for cloud-init deactivate ssh later
                            if [ $j -gt 20 ] ; then
                                # retries finished
                                switchstate FINISHED
                                continue
                            else
                                j=$(( j + 1 ))
                                echo "Release image -> Check ssh status again -> loop #$j ..."
                            fi
                        else
                            echo  "Develop image -> ssh is already activated. Nothing to do"
                            switchstate FINISHED
                            continue
                        fi
                    elif [ "$SSH_STATE" = "deactivated" ] ; then
                        # ssh is deactivated
                        echo
                        echo "activate ssh"
                        http_code=$(curl -s -o /dev/null -w "%{http_code}" -k -X PUT -H "Content-Type: application/json" -H "Authorization: Bearer $TOKEN" \
                            -d '{ "state": "activated" }' \
                            https://$DEVICE/ssh/api/v1/status 2>/dev/null)

                        if [ "$?" -eq "0" ] && [ "$http_code" -eq "200" ]; then
                            switchstate FINISHED
                            continue              
                        else
                            echo  "Failed to activate ssh: $http_code."
                            switchstate FAILED
                            continue
                        fi
                    fi
                fi
                ;;
            FINISHED)
                return 0
                ;;
            FAILED)
                return 1
                ;;
        esac
        sleep 5
        i=$(( i - 1 ))
    done
    echo -e "\n=== TIMEOUT ===\n"
}


function convertBoardName()
{
    # convert board name
    # ctrlXCore_M4      -> M4
    # ctrlXCore_XCS_M3  -> XCS_M3
    # ctrlXCore_M4_X2   -> X2
    # ctrlXCore_Plus_X3 -> M4plus
    # ctrlXCore_X7      -> X7

    local board_name=$1
    local retval=""

    case $board_name in
        ctrlXCore_M4)
            retval="M4"
            ;;
        ctrlXCore_M4_sysbase)
            retval="M4"
            ;;        
        ctrlXCore_XCS_M3)
            retval="XCS_M3"
            ;;
        ctrlXCore_M4_X2)
            retval="X2"
            ;;
        ctrlXCore_X7)
            retval="X7"
            ;;
        ctrlXCore_Plus_X3)
            retval="M4plus"
            ;;
        ctrlXCore_Plus_X3_sysbase)
            retval="M4plus"
            ;;
        ctrlXCore_conga-SEVAL)
            retval="congaSEVAL"
            ;;
        ctrlXCore_KBoxA250APL)
            retval="KBoxA250APL"
            ;;
        *)
            echo "ERROR: unknown Board"
        ;;
    esac
    echo "$retval"
} 

# make a powercycle of the target / board and wait until we reconnect to it
#
# Usage: target_powercycle MAX_REBOOT_RETRIES BOARD RACK
#
# [Note] retries are used instead of a simple timeout because
# 'cmd' may have an underlying timeout (e.g.: ConnectTimeout=15
# for ssh).
function target_powercycle {
  
    BOARD=$2
    RACK=${3:-ubuntu_core}
    # USB_DEV="${3:-$'/dev/sdb1'}"
    echo "INFO: BOARD=${BOARD}"
    echo "INFO: RACK=${RACK}"

    # convert board name for use with laborbuddy
    NEW_BOARD=$(convertBoardName $BOARD)
    echo "INFO: NEW_BOARD_NAME-> $NEW_BOARD"

    # set environment variables for Laborbuddy
    source /fuego-ro/tools/laborbuddy/scripts/setEnvironment.sh

    if [ "$RACK" = "sys_base" ] ; then
        PREFIX=SYS_BASE
    else
        PREFIX=SYS_UBUNTUCORE
    fi

    var1=INTEGRATION_${PREFIX}_IP_LABORKNECHT
    var2=INTEGRATION_${PREFIX}_OUTPUT_${NEW_BOARD}
    var3=INTEGRATION_${PREFIX}_IP_${NEW_BOARD}
    echo "INFO: var1 -> $var1"
    echo "INFO: var2 -> $var2"
    echo "INFO: var3 -> $var3"

    LABORBUDDY_IP_ADDRESS=${!var1}
    OUTPUT=${!var2}
    DEVICE=${!var3}
    echo "INFO: LABORBUDDY_IP_ADDRESS -> $LABORBUDDY_IP_ADDRESS"
    echo "INFO: OUTPUT -> $OUTPUT"
    echo "INFO: DEVICE -> $DEVICE"

    echo "BOARD <$BOARD> in Rack <$RACK> will do a powercycle in 10 seconds ..."
    sleep 10

    source /fuego-ro/tools/laborbuddy/scripts/run.sh $LABORBUDDY_IP_ADDRESS ${OUTPUT}_Off
    sleep 5
    source /fuego-ro/tools/laborbuddy/scripts/run.sh $LABORBUDDY_IP_ADDRESS ${OUTPUT}_On
    # give time for reboot to turn off networking, before waiting
    # for target to come back up
    sleep 15
    # set +e because some operations may fail before reboot completes
    set +e
    # pass max_retries to ov_transport_connect
    ov_transport_connect $1
    set -e
    cmd "true" || abort_job "ERROR: Cannot connect to board after reboot\n"
}

function target_reboot_uc20_update {
  ov_rootfs_reboot
  # give time for reboot to turn off networking, before waiting
  # for target to come back up
  sleep 30
  
  # set +e because some operations may fail before reboot completes
  set +e

  # check rescuesystem connection
  check_rescuesystem_connection_after_update
 
  # if rescues system is online switch power off and on (powercycle)
  BOARD=$2
  
  #board variable initialisation
  case $BOARD in
    ctrlXCore_M4)
        DEVICE="192.168.1.68"
        OUTPUT="Output0.0"
        ;;
    ctrlXCore_XCS_M3)
        DEVICE="192.168.1.64"
        OUTPUT="Output0.1"
        ;;
    ctrlXCore_M3)
        DEVICE="192.168.1.66"
        OUTPUT="Output0.2"
        ;;
    ctrlXCore_M4_X2)
        DEVICE="192.168.1.78"
        OUTPUT="Output0.2"
        ;;
    ctrlXCore_X7)
        DEVICE="192.168.1.90"
        OUTPUT="Output0.3"
        ;;
    ctrlXCore_Plus_X3)
        DEVICE="192.168.1.82"
        OUTPUT="Output0.4"
        ;;
    *)
        echo "ERROR: unknown Board"
    ;;
  esac

  echo "BOARD $BOARD will do a powercycle in 10 seconds ..."

  sleep 10

  source /fuego-ro/tools/laborbuddy/scripts/run.sh ${OUTPUT}_Off
  sleep 5
  source /fuego-ro/tools/laborbuddy/scripts/run.sh ${OUTPUT}_On

  #check_connection
  check_connection_after_update
  
  # pass max_retries to ov_transport_connect
  ov_transport_connect $1
  
  set -e
  cmd "true" || abort_job "ERROR: Cannot connect to board after reboot\n"
}

function target_reboot_update {
  ov_rootfs_reboot
  # give time for reboot to turn off networking, before waiting
  # for target to come back up

  BOARD=$2

  echo "Wait for BOARD $BOARD ..."
  if [ "$BOARD" = "ctrlXCore_X7" ] ; then
    sleep 80
  elif [ "$ARCHITECTURE" = "x86_64" ] ; then
    sleep 80
  else
    sleep 30
  fi

  # set +e because some operations may fail before reboot completes
  set +e

  #check_connection
  check_connection_after_update
  
  # pass max_retries to ov_transport_connect
  ov_transport_connect $1
  
  set -e
  cmd "true" || abort_job "ERROR: Cannot connect to board after reboot\n"
}

function target_reconnect {
  # give time for reboot to turn off networking, before waiting
  # for target to come back up
  sleep 5
  # set +e because some operations may fail before reboot completes
  set +e
  local max_retries=1
  if [ -n "$1" ] ; then
    max_retries=$1
  fi
  export SSHPASS=$PASSWORD
  # override default timeout settings for ssh
  export SSH_ARGS="-o ServerAliveInterval=10 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=error -o ConnectTimeout=10 -p $SSH_PORT $LOGIN@"
  
  retries=0
  while [ $retries -le $max_retries ] ; do
    ov_transport_cmd "true"
    if [ $? -eq 0 ] ; then
        return $retries
    fi
    sleep 1
    retries=$(( $retries + 1 ))
  done
  # ov_transport_connect $1
  set -e
  cmd "true" || abort_job "ERROR: Cannot connect to board after reboot\n"
  return 255
}

# check that a process ($1 is the process name) is running on the target
function check_process_is_running_on_target {
    safe_cmd "pgrep -f $1 1> /dev/null"
    if [ $? -eq 1 ]; then
        abort_job "process $1 is not running"
    fi
}
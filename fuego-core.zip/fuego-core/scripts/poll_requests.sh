#!/bin/bash
#
# poll_requests.sh - this is a simple script to do an infinite loop
# polling for requests (for my lab) on the fuego server. If a job
# is found, it is executed.
#
# edit the following values to modify the default behavior of poll_requests.sh
# WAIT_TIME, REMOVE_REQUESTS, BOARD

# wait time between polling, in seconds
WAIT_TIME=60

# remove requests from server (1=remove, 0=don't remove)
REMOVE_REQUESTS=0

# if BOARD is set, only process requests for the indicated board
#BOARD="min1"

usage() {
   cat <<HERE
Usage: poll_requests.sh [-h] [-w <seconds>] [-r] [-b <board>]

Poll for requests from the fuego server (configured in fuego.conf).
Execute any requests found, and repeat.

Options:
  -h, --help    Show this usage help
  -w <seconds>  Specify waiting period between polling requests, in seconds
                  (default is 60 seconds)
  -r            Remove requests from the server when the request is completed
                  (default is to not remove completed requests)
  -b <board>    Specify a board to execute requests for.  If not specified,
                  execute requests for any board in the local system.
HERE
}

while [ -n "$1" ]
do
    case $1 in
        -h|--help )
            usage
            exit 0
            ;;
        -w )
            shift ;
            if [ -z $1 ] ; then
                echo "Error: Missing wait time for -w option"
                echo "Use -h for help" ;
                exit 1
            fi
            WAIT_TIME="$1" ;
            shift ;
            ;;
        -r )
            shift ;
            REMOVE_REQUESTS=1
            ;;
        -b )
           shift ;
           BOARD="$1" ;
           shift ;
           ;;
        * )
           echo "Error: unrecognized option \"$1\"" ;
           echo "Use -h for help" ;
           exit 1 ;
     esac
done

# set BOARD_ARG from BOARD
if [ -n "${BOARD}" ] ; then
    BOARD_ARG="board=$BOARD"
else
    BOARD_ARG=""
fi

# only check for jobs for my host
HOST=$(ftc config host)
HOST_ARG="host=$HOST"


server_type=$(ftc config server_type)
server_domain=$(ftc config server_domain)
if [ "$server_type" == "fuego" -a -n "$server_domain" ] ; then
    echo "== Polling server \"$server_domain\" for requests =="
    if [ -n "$BOARD_ARG" ] ; then
        echo "Processing requests for $BOARD_ARG"
    else
        echo "Processing requests for any board"
    fi
else
    echo "Error: fuego.conf does not have a valid configuration for Fuego server"
    echo "Please add a Fuego server to fuego.conf in order to poll for requests."
    exit 1
fi

# check to see that my host has at least one board registered with fserver
is_there=$(ftc list-boards -r | grep -q "$HOST:" ; echo $?)
if [ $is_there != "0" ] ; then
    echo "Error: no boards for this host ($HOST) are registered with the server"
    echo "Check the boards on the server with 'ftc list-boards -r'"
    echo "It makes no sense to poll for requests."
    echo "Please register a board with the fserver, and try again."
    echo "Alternatives, check your fserver configuration in fuego.conf"
    exit 1
fi

echo "Type Ctrl-C to exit"

while true ; do
    echo -n "Checking "
    request_id="$(ftc list-requests -q ${HOST_ARG} ${BOARD_ARG} state=pending | head -n 1)"
    if [ -n "${request_id}" ] ; then
        echo
        echo "Running request: $request_id"
        ftc run-request --put-run $request_id ;
        if [ "$REMOVE_REQUESTS" = "1" ] ; then
            ftc rm-request $request_id ;
        fi
    else
        echo -n "Waiting "
        for i in $(seq $WAIT_TIME) ; do
            echo -n "."
            sleep 1
        done
        echo
    fi
done

function test_run {
    RESULT=$(( 1000 + (RANDOM % 600 - 300) ))
    report "echo fuego_check_plots result: $RESULT"
}



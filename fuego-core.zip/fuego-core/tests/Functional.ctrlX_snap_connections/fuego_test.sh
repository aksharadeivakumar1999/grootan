# Functional.ctrlX_snap_connections
#  Interfaces allow (or deny) access to a resource outside of a snap’s confinement.
#  Normally all interfaces should be connected automatically during startup.
#
#  This test is to check, if all interfaces are connected automatically or not.
#
#  The purpose of this test is to do an analysis on all the snap interfaces, to see
#  if the interfaces are connected manually or automatically and then notify the user
#  about the connection details.
#
# Test Cases:
#  1. If all the snap interfaces are connected automatically then put a notice to
#     the test log mentioning the same.
#       - Save the list of all the snap connections to a file -> Test-Result: SUCCESS
#
#  2. If even one interface is connected manually then put a notice to the test log
#     indicating the presence of manually connected interfaces -> Test-Result: ERROR
#       - Display the list & number of all the connections that have manually connected
#         interfaces and print them to the console & fuego log file.
#
# Usage:
#  Preparation:
#    Create test job:
#      $ ftc add-job -b <board> -t Functional.ctrlX_snap_connections -s default
#    Run the test:
#      $ ftc build-job <board>.default.Functional.ctrlX_snap_connections
#      This test will report success or failure based on the connections found.
#        - In case of success the test saves all the snap connections in
#               $LOGDIR/Functional.ctrlX_snap_connections.txt
#        - In case of failure the test saves the list of manually connected
#          interfaces (snap connections) in
#               $LOGDIR/Functional.ctrlX_snap_connections-manual.txt
#    Validate the data in the file:
#      Inspect the data in the Functional.ctrlX_snap_connections-manual.txt file & take
#      necessary actions.
#
# Periodic usage:
#    Run the test as part of your test cycle:
#      $ ftc build-job <board>.default.Functional.ctrlX_snap_connections

function test_run {
    report "cd $BOARD_TESTDIR/fuego.$TESTDIR; echo \"Getting snap connections...\""

    DATA_FILE=$LOGDIR/$TESTDIR.txt
    MANUAL_CONN=$LOGDIR/$TESTDIR-manual.txt
    MANUAL_COUNT=0

    log_this "echo \"### Here are the snap connections on $NODE_NAME:\""

    # Get the snap connections from the board
    cmd "snap connections" |& tee $DATA_FILE
    if [ "${PIPESTATUS[0]}" != "0" ]; then
        echo "ERROR: The snap connections has failed!!"
        return 1
    else
        report_append "echo -e \"\nINFO: The snap connections have been fetched successfully...\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
        log_this "echo ----------------------------------------------------------------------------"
    fi
    log_this "echo \"Checking for manually connected interfaces...\""

    # Get the manually connected interfaces from the board
    cmd "snap connections | grep manual" |& tee $MANUAL_CONN > /dev/null

    # Test-Case-1:
    # All the snap interfaces are connected automatically: Functional.ctrlX_snap_connections-manual.txt file is empty
    # Test-Case-2:
    # One or more snap interfaces are connected manually: Functional.ctrlX_snap_connections-manual.txt file has the list
    if [ ! -s $MANUAL_CONN ] ; then
        log_this "echo \"INFO: No manually connected interfaces found\""
        report_append "echo \"SUCCESS: All the snap interfaces are connected automatically\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
    else
        log_this "echo -e \"ERROR: Manually connected interfaces found!!\nINFO: List of manually connected interfaces:\""
        log_this "cat $MANUAL_CONN"
        log_this "echo \"Please find the list of manually connected interfaces in '$MANUAL_CONN'\""
        put $MANUAL_CONN $BOARD_TESTDIR/fuego.$TESTDIR/
        MANUAL_COUNT=$(cmd "grep -wc manual $BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR-manual.txt")
        report_append "echo \"ERROR: $MANUAL_COUNT snap interfaces are connected manually...Exiting!!\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
     fi
}

function test_processing {
    log_compare $TESTDIR 1 "^SUCCESS" "p"
}

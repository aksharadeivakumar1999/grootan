# Functional.ctrlX_snap_system_options
#  Snap supports a set of system-wide options that allow you to customise 
#  your snap or Ubuntu Core environment. This options are specified during 
#  Ubuntu Core image build.
#
#  This test is to check if the snap options were set correctly during 
#  the build process.
#  
#  The purpose of this test is to do a high-level comparison of the 
#  snap options of system, to see if anything has changed since 
#  the last baseline snapshot was made.
# 
# Test-Cases:
#  1. If no baseline file is available then create the baseline and put 
#     a notice to the test log that a new baseline file was created. 
#     Save baseline file to test framework for later run (could be a
#     manual process) -> Test-Result: ERROR
#
#  2. If baseline file is available but snap system setting dump differ to 
#     the predefined baseline file -> Test-Result: ERROR
#       - Check the new snap options and validate them. If the changes are correct 
#         then a new baseline file has to be created (could be a manual process)
#
#  3. If baseline file is available and snap system setting dump is equal to the 
#     predefined baseline file -> Test-Result: SUCCESS
#
# Usage:
#  Preparation:
#    Create test job:
#      $ ftc add-job -b <board> -t Functional.ctrlX_snap_system_options -s default
#    Run the test the first time:
#      $ ftc build-job <board>.default.Functional.ctrlX_snap_system_options
#      This test will report failure, but will save the baseline file with warning
#      (snap system options) in
#         fuego-rw/boards/<board>/Functional.ctrlX_snap_system_options-baseline-data.json
#    Validate the baseline data:
#      Manually inspect the data in the baseline data file. If it is correct
#      then remove the warning lines from the top of the file.
# 
# Periodic usage:
#    Run the test as part of your test cycle:
#      $ ftc build-job <board>.default.Functional.ctrlX_snap_system_options
# 
# If the snap system options change, or the baseline data is incorrect:
#    Create a baseline data file and save it as
#      fuego-rw/boards/<board>/Functional.ctrlX_snap_system_options-diff-baseline-data.json
#
# To permanently save the data after validating, rename the baseline data file in 
#    "fuego-rw/boards/<board>/Functional.ctrlX_snap_system_options-diff-baseline-data.json" to 
#    "fuego-rw/boards/<board>/Functional.ctrlX_snap_system_options-baseline-data.json"
#

function test_pre_check {
    export board_rw_dir=$FUEGO_RW/boards/$NODE_NAME

    mkdir -p $board_rw_dir

    export rw_baseline_file=$board_rw_dir/$TESTDIR-baseline-data.json
    
    # Check if the baseline data file exists
    if [ -f $rw_baseline_file ] ; then
        echo "Baseline file exists..Continue with the test."
    else
        echo "Warning: Missing baseline results file: $rw_baseline_file!!"
        echo "INFO: Creating a baseline file & Saving it in the test framework for verification!!"
    fi
}

function test_run {
    report "cd $BOARD_TESTDIR/fuego.$TESTDIR; echo \"Getting snap system options...\""

    DATA_FILE=$LOGDIR/snap_options.json

    # Get the snap system options from the board
    cmd "sudo snap get -d system" >$DATA_FILE

    log_this "echo \"### Here are the snap system options on $NODE_NAME:\""
    log_this "cat $DATA_FILE"
    report_append "echo \"INFO: The snap system options have been fetched successfully...\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"

    # Test-Case-1:
    # Baseline file is Missing : Create a baseline file & Save the data with a warning
    if [ ! -f $rw_baseline_file ] ; then
        echo "# Warning: Baseline data saved during the test!!" >$rw_baseline_file
        echo "# Please review the data and remove this header if the data is correct." >>$rw_baseline_file
        cat $DATA_FILE >>$rw_baseline_file
        report_append "echo \"INFO: Baseline file: $rw_baseline_file saved...\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
        report_append "echo \"ERROR: Baseline file Missing..Exiting!!\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
        return 1
    fi

    # Test-Case-2:
    # Baseline file is Available, but Snap system setting dump differs with the predefined baseline file
    # Check for differences from baseline
    if [ -f $rw_baseline_file ] ; then
        set +e
        report_append "echo \"Checking for differences in snap system options with the baselined data\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
        log_this "diff -u $rw_baseline_file $DATA_FILE"
        diff_rcode="$?"
        report_append "echo -------------------------------------------------" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
        set -e
    fi

    # Test-Case-3:
    # Baseline file is Available, Snap system setting dump equal to predefined baseline file
    if [ $diff_rcode == "0" ] ; then
        report_append "echo \"No changes found between current snap system options and baseline\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
	    report_append "echo \"SUCCESS: Comparison with the baseline data returned 0 differences\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
    else
        report_append "echo \"Snap system options are different from baseline\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
        export diff_rw_baseline_file=$board_rw_dir/$TESTDIR-diff-baseline-data.json
        cp $DATA_FILE $diff_rw_baseline_file
	    report_append "echo \"ERROR: Not OK Comparison with the baseline data returned differences\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
    fi
}

function test_processing {
    log_compare $TESTDIR 1 "^SUCCESS" "p"
}

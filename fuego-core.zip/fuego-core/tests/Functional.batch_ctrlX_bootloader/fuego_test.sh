# test to test hello with different specs and arguments
#
# Notes:
# - each sub-test is a testcase
# - we use TAP output to summarize the results for this test
#

BATCH_TESTPLAN=$(cat <<END_TESTPLAN
{
    "testPlanName": "ctrlX_bootloader",
    "default_timeout": "60m",
    "default_spec": "default",
    "default_reboot": "false",
    "default_rebuild": "false",
    "default_precleanup": "true",
    "default_postcleanup": "true",
    "tests": [
        { "testName": "Functional.ctrlX_update", "spec": "update_image", "timeout": "15m" },
        { "testName": "Functional.ctrlX_update", "spec": "update_bootloader", "timeout": "10m" }
    ]
}
END_TESTPLAN
)

function test_run {
    export TC_NUM=1
    DEFAULT_TIMEOUT=60m
    export FUEGO_BATCH_ID="ctrlX_bootloader-$(allocate_next_batch_id)"

    # don't stop on test errors
    set +e
    log_this "echo \"batch_id=$FUEGO_BATCH_ID\""
    run_test Functional.ctrlX_update -s update_image --timeout 15m
    run_test Functional.ctrlX_update -s update_bootloader --timeout 10m
    set -e
}

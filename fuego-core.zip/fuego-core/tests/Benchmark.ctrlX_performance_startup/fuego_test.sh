# Benchmark.ctrlX_performance_startup
#  The test should measure and log the boot performance of the ctrlX CORE
#  Linux Operating System with the goal to detect possible abnormalities.
#
#  The "systemd-analyze" command is used to determine system boot-up
#  performance statistics and retrieve other state and tracing information
#  from the system.
#
#  Additionally, the objective of this test is to determine the components
#  that require the most initialization / boot time.
#  For instance, command "systemd-analyze blame" determines the above information.
#
#  This test is a part of a series of tests to determine the startup
#  performance of the ctrlX CORE operating system and the app infrastructure
#  (apps like Device-Admin, Automation-Core, etc.) and the over-all time
#  of booting.
#  This test-case is structured in such a way that it can be extended in future.
#
#  Currently, only reboot type "soft-reboot" is being tested. Later it can
#  be enabled to support a hard reset (power-cycle).
#
# Test-Cases:
#  1. Soft Reboot of the system:
#     a. If the controller is up after ample amount of time -> Test-Result: SUCCESS
#     b. If the controller is not responding post reboot -> Test-Result: ERROR
#
#  2. If no pre-defined criteria file is available. Report failure and save boot-up
#     statistics file to test framework -> Test-Result: ERROR
#
#  3. If pre-defined criteria file is available but boot-up statistics are beyond
#     the defined range -> Test-Result: ERROR
#       - Observe the variation in values over a period of time and in case of
#         consistency in deviation, update the values defined in the criteria file
#         (could be a manual process)
#
#  4. If pre-defined criteria file is available and boot-up statistics data is same
#     as the one defined in it -> Test-Result: SUCCESS
#
# Usage:
#  Preparation:
#    [Note: This test is currently running for linuxOS spec. Can be extended in future
#           for new apps / devices, if required]
#    Create test job:
#      $ ftc add-job -b <board> -t Benchmark.ctrlX_performance_startup -s linuxOS
#    Run the test:
#      $ ftc build-job <board>.linuxOS.Benchmark.ctrlX_performance_startup
#      This test will report success & save the information of bootup statistics and
#      the components with their initialization time respectively in
#         'fuego-rw/logs/Benchmark.ctrlX_performance_startup/<board>.linuxOS.<build>.<build>/'
#         directory as "linuxOS-bootup-statistics.txt" & "component_init-time.txt"
#   Validate the bootup statistics against the criteria data:
#      Perform comparison of the statistics against the range defined in the criteria.json
#      file. If it is incorrect then report failure. Observe these values over a period of
#      time and update them, if necessary.
#      Note: The criteria.json file for each target is defined in
#         '/fuego-rw/boards/<board>-Benchmark.ctrlX_performance_startup-criteria.json'
#
# Periodic usage:
#    Run the test as part of your test cycle:
#      $ ftc build-job <board>.linuxOS.Benchmark.ctrlX_performance_startup
#

function test_pre_check {
    export rw_criteria_file=$FUEGO_RW/boards/$NODE_NAME-$TESTDIR-criteria.json

    # Ensure reboot type & number of retries / wait time for reboot is defined
    assert_define BENCHMARK_CTRLX_PERFORMANCE_STARTUP_REBOOT_TYPE

    if [ "$BENCHMARK_CTRLX_PERFORMANCE_STARTUP_REBOOT_TYPE" = "soft" ] ; then
        assert_define BENCHMARK_CTRLX_PERFORMANCE_STARTUP_REBOOT_RETRIES
    fi

    # Checking the existence of criteria file
    if ! [[ -a $rw_criteria_file ]]; then
        err=1
        echo "ERROR: Pre-defined criteria.json file is missing in '$rw_criteria_file' path!!"
        echo -e "WARNING: Default criteria file created!! No comparison will be performed for the boot-up statistics!!\n"
    fi
}

function test_run {
    bootup_stats=$LOGDIR/$TESTSPEC-bootup-statistics.txt
    init_time=$LOGDIR/component_init-time.txt
    active_jobs=$LOGDIR/active-jobs.txt
    journal_log=$LOGDIR/journal-log.txt
    counter=0

    # Reboot the target & Wait until the target is up prior to execution of test.
    reboot_retries=${BENCHMARK_CTRLX_PERFORMANCE_STARTUP_REBOOT_RETRIES:-50}

    report "cd $BOARD_TESTDIR/fuego.$TESTDIR; echo \"Rebooting the '$NODE_NAME' device [$BENCHMARK_CTRLX_PERFORMANCE_STARTUP_REBOOT_TYPE-reboot]...\""

    if [ "$BENCHMARK_CTRLX_PERFORMANCE_STARTUP_REBOOT_TYPE" = "soft" ] ; then
        target_reboot $reboot_retries && log_this "echo \"Rebooting '$NODE_NAME' done...\"" || echo "Rebooting '$NODE_NAME' failed (Error-Code:$?)!!"
    fi

    # Additionaly delay because remote system may have networking up, but need more
    # time to mount filesystems
    sleep 20

	# Get the boot-up statistics from the device
    set +e
    log_this "echo -e \"\nChecking for active services [if any] after reboot...\""

    # Looping to ensure all the services are booted up
    while [ $counter -le 2 ]
    do
	#listing the status of active systemd jobs
        cmd "systemctl list-jobs" |& tee $active_jobs
        
        if grep -R "No jobs running." $active_jobs > /dev/null ; then
            counter=3
            report_append "echo -e \"\nStatus of services: $(cat $active_jobs) \nGetting boot-up statistics of $NODE_NAME's $TESTSPEC spec...\"" \
            "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
            log_this "echo -e \"\n### Here is the boot-up statistics on $NODE_NAME:\""
            
            report_append "systemd-analyze" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log" |& tee $bootup_stats && \
            log_this "echo -e \"\nINFO: Fetching the boot-up statistics done...\"" || log_this "echo \"ERROR: Failure in getting the boot-up statistics!!\""
	     #deleting active-jobs.txt file from log directory if No jobs are running
	     rm -rf $active_jobs
        else
            log_this "echo -e \"\nERROR: $(cat $active_jobs) \nServices are still running...Waiting to allow booting of running services to complete...\""

            # Additional delay to allow the services to bootup completely
            sleep 60

            # Increment the counter
            ((counter++))

            # Buffer delay to ensure all the services are up & running
            if [ $counter -eq 2 ]; then
                log_this "echo -e \"\nWARNING: Services are currently running...Additional delay after $counter retires...\""
                sleep 120
            elif [ $counter -gt 2 ]; then
                cmd "sudo journalctl -b" > $journal_log
                log_this "echo -e \"\nERROR: Terminating the execution due to failure in booting up the services!!\
                \nPlease find a detailed journal log for the failure in '$journal_log'...Exiting!!\""
                log_this "echo -------------------------------------------------"
                exit 1
            fi
        fi
    done

    log_this "echo -------------------------------------------------"

    # Intentional delay before fetching the data for time
    sleep 5

    # Get the initialization time for all the components
    # Top-10 components with the highest initialization time (using head command)
    report_append "echo -e \"Fetching the components with their respective initialization time on $NODE_NAME:\n\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"

    report_append "systemd-analyze blame" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log" |& tee $init_time && \
    ( log_this "echo -e \"\nINFO: Fetching the initialization time of all the components done...\
        \n### Here is a list of components with the highest initialization time:\"" && \
        head $init_time || echo "ERROR: Listing the Top-10 components failed!!" ) || \
        ( report_append "echo \"ERROR: Failure in the process of fetching initialization time for components!!\"" "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log" )

    log_this "echo -e \"\nINFO: Please find the Boot-up statistics & Initialization time data (if passed) in $bootup_stats & $init_time\""

    if [[ -s $bootup_stats && -s $init_time && $err -eq 0 ]]; then
        report_append "echo -e \"\nSUCCESS: Boot-up statistics & Initialization time for all the components fetched successfully!!\"" \
            "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
    else
        report_append "echo -e \"\nERROR: Criteria file missing or Fetching Boot-up statistics / Initialization time for all the components failed!!\"" \
            "$BOARD_TESTDIR/fuego.$TESTDIR/$TESTDIR.log"
    fi
    set -e
}

function test_processing {
    log_compare $TESTDIR 1 "^SUCCESS" "p"
}

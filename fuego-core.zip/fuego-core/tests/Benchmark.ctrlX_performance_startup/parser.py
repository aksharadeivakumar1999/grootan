#!/usr/bin/python
import os, re, sys
import common as plib

# Parsing values only for default & linuxOS spec
# Can be extended in future for other specs
regex_string = "\s=\s\d+.\d+\D\s$"
measurements = {}
testspec = plib.TESTSPEC
matches = (re.split('(\d+.\d+)', (plib.parse_log(regex_string))[0]))[1]

# Creating measurement dictionary to compare statistics against threshold values
if matches:
	if ((testspec == "default") or (testspec == "linuxOS")):
		measurements['default.bootup'] = [
			{"name": "max_time", "measure" : float(matches)},
			{"name": "min_time", "measure" : float(matches)}]
		measurements['linuxOS.bootup'] = [
			{"name": "max_time", "measure" : float(matches)},
			{"name": "min_time", "measure" : float(matches)}]

sys.exit(plib.process(measurements))
